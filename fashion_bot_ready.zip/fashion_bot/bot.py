import os, asyncio, json, sqlite3, random, string
from datetime import datetime
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from aiogram.types import (Message, InlineKeyboardMarkup, InlineKeyboardButton,
    WebAppInfo, CallbackQuery, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

BOT_TOKEN = os.environ["BOT_TOKEN"]
ADMIN_ID  = int(os.environ["ADMIN_ID"])
WEB_URL   = os.getenv("WEB_APP_URL", "https://uzum-pro-bot.onrender.com")
SHOP_NAME = os.getenv("SHOP_NAME", "FASHION STORE")
SUPPORT   = os.getenv("SUPPORT", "@support")
DB_NAME   = os.getenv("DB_NAME", "fashion.db")
CHANNEL   = os.getenv("CHANNEL_ID", "@channel")

bot     = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
storage = MemoryStorage()
dp      = Dispatcher(storage=storage)

class AddItem(StatesGroup):
    media    = State()
    name     = State()
    price    = State()
    old_price= State()
    desc     = State()
    sizes    = State()
    colors   = State()
    stock    = State()
    category = State()

class BC(StatesGroup):
    msg = State()

class OrdReply(StatesGroup):
    msg = State()

def db():
    c = sqlite3.connect(DB_NAME)
    c.row_factory = sqlite3.Row
    return c

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def fmt(n):
    try: return f"{int(n):,}".replace(",", " ")
    except: return str(n)

def init_db():
    conn = db(); c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS categories(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE, icon TEXT DEFAULT '👗', sort_order INTEGER DEFAULT 0)""")
    c.execute("""CREATE TABLE IF NOT EXISTS products(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER DEFAULT 1,
        name TEXT NOT NULL, description TEXT DEFAULT '',
        price INTEGER NOT NULL, old_price INTEGER DEFAULT 0,
        image TEXT DEFAULT '', video TEXT DEFAULT '',
        badge TEXT DEFAULT 'NEW', stock INTEGER DEFAULT 99,
        active INTEGER DEFAULT 1, rating REAL DEFAULT 4.5,
        sold_count INTEGER DEFAULT 0,
        sizes TEXT DEFAULT 'S,M,L,XL',
        colors TEXT DEFAULT '',
        created_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_user_id TEXT, full_name TEXT, phone TEXT,
        items TEXT, total INTEGER,
        status TEXT DEFAULT 'new',
        note TEXT DEFAULT '',
        size TEXT DEFAULT '', color TEXT DEFAULT '',
        created_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_user_id TEXT UNIQUE, full_name TEXT,
        username TEXT, referral_code TEXT UNIQUE,
        referred_by TEXT DEFAULT '',
        points INTEGER DEFAULT 0,
        orders_count INTEGER DEFAULT 0,
        total_spent INTEGER DEFAULT 0,
        blocked INTEGER DEFAULT 0,
        joined_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS promo_codes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE, discount_percent INTEGER DEFAULT 10,
        max_uses INTEGER DEFAULT 100, used_count INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1, created_at TEXT)""")

    c.execute("SELECT COUNT(*) FROM categories")
    if c.fetchone()[0] == 0:
        cats = [
            ("Ayollar kiyimi","👗",1),("Erkaklar kiyimi","👔",2),
            ("Bolalar kiyimi","🧒",3),("Sport kiyim","🏋️",4),
            ("Poyabzal","👟",5),("Aksessuarlar","💍",6),
        ]
        c.executemany("INSERT INTO categories(name,icon,sort_order) VALUES(?,?,?)", cats)

    c.execute("SELECT COUNT(*) FROM promo_codes")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO promo_codes(code,discount_percent,max_uses,active,created_at) VALUES(?,?,?,?,?)",
                  ("FASHION10", 10, 1000, 1, now()))

    conn.commit(); conn.close()

def get_user(tg_id):
    conn = db()
    r = conn.execute("SELECT * FROM users WHERE tg_user_id=?", (str(tg_id),)).fetchone()
    conn.close()
    return dict(r) if r else None

def reg_user(tg_id, name, username, ref=""):
    conn = db(); c = conn.cursor()
    ex = conn.execute("SELECT id FROM users WHERE tg_user_id=?", (str(tg_id),)).fetchone()
    if not ex:
        rc = ''.join(random.choices(string.ascii_uppercase+string.digits, k=8))
        c.execute("INSERT INTO users(tg_user_id,full_name,username,referral_code,referred_by,joined_at) VALUES(?,?,?,?,?,?)",
                  (str(tg_id), name, username or "", rc, ref, now()))
        if ref:
            c.execute("UPDATE users SET points=points+200 WHERE referral_code=?", (ref,))
        conn.commit()
    conn.close()

STATUS = {
    "new":("🆕","Yangi"), "confirmed":("✅","Tasdiqlangan"),
    "delivering":("🚚","Yetkazilmoqda"), "delivered":("🎉","Yetkazildi"),
    "cancelled":("❌","Bekor"),
}

def order_text(o, admin=False):
    em, lb = STATUS.get(o.get("status","new"), ("❓","?"))
    try: items = json.loads(o.get("items","[]"))
    except: items = []
    lines = "".join(
        f"  • {i.get('name','?')} {i.get('size','')} {i.get('color','')} × {i.get('qty',1)} — {fmt(i.get('price',0)*i.get('qty',1))} so'm\n"
        for i in items[:10])
    t = f"{em} <b>Buyurtma #{o['id']}</b> — <b>{lb}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
    if admin: t += f"👤 ID: <code>{o.get('tg_user_id','-')}</code>\n"
    t += f"🙋 <b>{o.get('full_name','-')}</b>\n📞 <code>{o.get('phone','-')}</code>\n"
    if o.get("size"):  t += f"📏 {o['size']}\n"
    if o.get("color"): t += f"🎨 {o['color']}\n"
    if o.get("note"):  t += f"💬 {o['note']}\n"
    t += f"\n🛍 Mahsulotlar:\n{lines}\n💰 <b>Jami: {fmt(o.get('total',0))} so'm</b>\n🕐 {o.get('created_at','')}"
    return t

def order_kb(oid, status):
    kb = InlineKeyboardBuilder()
    if status == "new":
        kb.button(text="✅ Tasdiqlash",   callback_data=f"o_confirm_{oid}")
        kb.button(text="❌ Bekor qilish", callback_data=f"o_cancel_{oid}")
    elif status == "confirmed":
        kb.button(text="🚚 Yo'lda",       callback_data=f"o_deliver_{oid}")
        kb.button(text="❌ Bekor",         callback_data=f"o_cancel_{oid}")
    elif status == "delivering":
        kb.button(text="🎉 Yetkazildi",   callback_data=f"o_done_{oid}")
    kb.button(text="💬 Xabar yozish",     callback_data=f"o_reply_{oid}")
    kb.adjust(2)
    return kb.as_markup()

async def is_sub(uid):
    try:
        m = await bot.get_chat_member(CHANNEL, uid)
        return m.status not in ("left","kicked","banned")
    except: return True

def admin_kb():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="➕ Mahsulot qo'shish")],
        [KeyboardButton(text="📦 Buyurtmalar"),   KeyboardButton(text="📊 Statistika")],
        [KeyboardButton(text="📢 Broadcast"),      KeyboardButton(text="🏷️ Promo kod")],
        [KeyboardButton(text="🗑 Mahsulot o'chirish"), KeyboardButton(text="👥 Mijozlar")],
        [KeyboardButton(text="🛍 Do'konni ko'rish", web_app=WebAppInfo(url=WEB_URL))],
    ], resize_keyboard=True)

def user_kb():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="🛍 Do'konni ochish", web_app=WebAppInfo(url=WEB_URL))],
        [KeyboardButton(text="📦 Buyurtmalarim"),  KeyboardButton(text="⭐ Ballarim")],
        [KeyboardButton(text="👥 Do'stni taklif"), KeyboardButton(text="📞 Yordam")],
    ], resize_keyboard=True)

def cat_kb():
    conn = db()
    cats = conn.execute("SELECT * FROM categories ORDER BY sort_order").fetchall()
    conn.close()
    kb = InlineKeyboardBuilder()
    for cat in cats:
        kb.button(text=f"{cat['icon']} {cat['name']}", callback_data=f"cat_{cat['id']}")
    kb.adjust(2)
    return kb.as_markup()

def badge_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔥 HOT",  callback_data="b_HOT"),
         InlineKeyboardButton(text="✨ NEW",  callback_data="b_NEW")],
        [InlineKeyboardButton(text="💸 SALE", callback_data="b_SALE"),
         InlineKeyboardButton(text="⭐ TOP",  callback_data="b_TOP")],
        [InlineKeyboardButton(text="🎁 GIFT", callback_data="b_GIFT"),
         InlineKeyboardButton(text="❌ Yo'q", callback_data="b_")],
    ])

# ── /START ────────────────────────────────────────────────────────────────────
@dp.message(CommandStart())
async def start(msg: Message, state: FSMContext):
    await state.clear()
    uid   = msg.from_user.id
    name  = f"{msg.from_user.first_name or ''} {msg.from_user.last_name or ''}".strip() or "Foydalanuvchi"
    uname = msg.from_user.username or ""
    args  = msg.text.split()
    ref   = args[1] if len(args) > 1 else ""
    reg_user(uid, name, uname, ref)

    if uid == ADMIN_ID:
        conn = db()
        prods = conn.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0]
        new_o = conn.execute("SELECT COUNT(*) FROM orders WHERE status='new'").fetchone()[0]
        users = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        rev   = conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status='delivered'").fetchone()[0]
        conn.close()
        await msg.answer(
            f"👑 <b>ADMIN — {SHOP_NAME}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"👗 Mahsulotlar: <b>{prods} ta</b>\n"
            f"🆕 Yangi buyurtmalar: <b>{new_o} ta</b>\n"
            f"👥 Mijozlar: <b>{users} ta</b>\n"
            f"💰 Jami daromad: <b>{fmt(rev)} so'm</b>",
            reply_markup=admin_kb()
        )
        return

    if not await is_sub(uid):
        await msg.answer(
            f"👋 Salom, <b>{name}</b>!\n\n"
            f"🔒 <b>{SHOP_NAME}</b> ga kirish uchun\n"
            "kanalimizga obuna bo'ling!",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="📢 Kanalga obuna bo'lish", url=f"https://t.me/{CHANNEL.lstrip('@')}")],
                [InlineKeyboardButton(text="✅ Obuna bo'ldim", callback_data="check_sub")],
            ])
        )
        return

    u = get_user(uid)
    pts = u["points"] if u else 0
    await msg.answer(
        f"👋 Salom, <b>{name}</b>!\n\n"
        f"👗 <b>{SHOP_NAME}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"⭐ Ballaringiz: <b>{fmt(pts)}</b>\n"
        "🎁 Yangi mijozlarga promo: <code>FASHION10</code> (-10%)\n\n"
        "👇 Do'konni oching:",
        reply_markup=user_kb()
    )

@dp.callback_query(F.data == "check_sub")
async def check_sub(call: CallbackQuery, state: FSMContext):
    if not await is_sub(call.from_user.id):
        await call.answer("❌ Hali obuna bo'lmagansiz!", show_alert=True); return
    await call.message.delete()
    uid   = call.from_user.id
    name  = f"{call.from_user.first_name or ''} {call.from_user.last_name or ''}".strip()
    reg_user(uid, name, call.from_user.username or "")
    await call.message.answer(
        f"✅ Xush kelibsiz, <b>{name}</b>!\n\n"
        "🎁 Birinchi xaridingizga: <code>FASHION10</code> (-10%)",
        reply_markup=user_kb()
    )

# ── USER ──────────────────────────────────────────────────────────────────────
@dp.message(F.text == "📦 Buyurtmalarim")
async def my_orders(msg: Message):
    conn = db()
    rows = conn.execute("SELECT * FROM orders WHERE tg_user_id=? ORDER BY id DESC LIMIT 5",
                        (str(msg.from_user.id),)).fetchall()
    conn.close()
    if not rows:
        await msg.answer("📭 Hali buyurtma bermadingiz!", reply_markup=user_kb()); return
    await msg.answer("📦 <b>Oxirgi 5 ta buyurtmangiz:</b>")
    for r in rows:
        o = dict(r)
        em, lb = STATUS.get(o["status"], ("❓","?"))
        await msg.answer(f"{em} <b>#{o['id']}</b> — {lb}\n💰 {fmt(o['total'])} so'm\n🕐 {o['created_at']}")

@dp.message(F.text == "⭐ Ballarim")
async def my_points(msg: Message):
    u = get_user(msg.from_user.id)
    if not u: await msg.answer("❌"); return
    await msg.answer(
        f"⭐ <b>Sizning profilingiz</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"👤 {u['full_name']}\n"
        f"⭐ Ballar: <b>{fmt(u['points'])}</b>\n"
        f"📦 Buyurtmalar: <b>{u['orders_count']}</b>\n"
        f"💰 Jami xarid: <b>{fmt(u['total_spent'])} so'm</b>\n\n"
        f"📌 1 000 so'm = 1 ball\n"
        f"📌 Do'st taklif = 200 ball",
        reply_markup=user_kb()
    )

@dp.message(F.text == "👥 Do'stni taklif")
async def referral(msg: Message):
    u = get_user(msg.from_user.id)
    if not u: return
    me = await bot.get_me()
    link = f"https://t.me/{me.username}?start={u['referral_code']}"
    conn = db()
    inv = conn.execute("SELECT COUNT(*) FROM users WHERE referred_by=?", (u['referral_code'],)).fetchone()[0]
    conn.close()
    await msg.answer(
        f"👥 <b>Referal</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"Do'stingizni taklif → <b>200 ball</b>!\n\n"
        f"🔗 Havolangiz:\n<code>{link}</code>\n\n"
        f"👥 Taklif qilganlar: <b>{inv}</b>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📤 Ulashish",
             url=f"https://t.me/share/url?url={link}&text=👗 {SHOP_NAME} — zo'r kiyimlar!")]
        ])
    )

@dp.message(F.text == "📞 Yordam")
async def support(msg: Message):
    await msg.answer(
        f"📞 <b>Yordam</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"Admin: {SUPPORT}\n🕐 09:00–22:00",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="💬 Adminga yozish", url=f"https://t.me/{SUPPORT.lstrip('@')}")]
        ])
    )

# ── ADMIN: MAHSULOT QO'SHISH ──────────────────────────────────────────────────
@dp.message(F.text == "➕ Mahsulot qo'shish")
async def add_start(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    await state.clear()
    await state.update_data(photos=[], videos=[])
    await msg.answer(
        "📸 <b>Mahsulot qo'shish</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        "Rasm yoki video yuboring (10 tagacha)\n\n"
        "Tugatgach pastdagi tugmani bosing:",
        reply_markup=ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="✅ Rasmlar tayyor, davom etish")]
        ], resize_keyboard=True)
    )
    await state.set_state(AddItem.media)

@dp.message(AddItem.media, F.photo)
async def got_photo(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    data   = await state.get_data()
    photos = data.get("photos", [])
    f      = await bot.get_file(msg.photo[-1].file_id)
    url    = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{f.file_path}"
    photos.append({"type":"photo","url":url,"file_id":msg.photo[-1].file_id})
    await state.update_data(photos=photos)
    await msg.answer(f"✅ {len(photos)}-rasm qabul qilindi! Yana yuboring yoki davom eting.")

@dp.message(AddItem.media, F.video)
async def got_video(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    data   = await state.get_data()
    photos = data.get("photos", [])
    f      = await bot.get_file(msg.video.file_id)
    url    = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{f.file_path}"
    photos.append({"type":"video","url":url,"file_id":msg.video.file_id})
    await state.update_data(photos=photos)
    await msg.answer(f"✅ Video qabul qilindi! Yana yuboring yoki davom eting.")

@dp.message(AddItem.media, F.text == "✅ Rasmlar tayyor, davom etish")
async def media_done(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    data = await state.get_data()
    if not data.get("photos"):
        await msg.answer("❌ Kamida 1 ta rasm yuboring!"); return
    await msg.answer("✏️ <b>Mahsulot nomini</b> yozing:\nMasalan: Oversize Futbolka",
                     reply_markup=ReplyKeyboardRemove())
    await state.set_state(AddItem.name)

@dp.message(AddItem.name)
async def got_name(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    await state.update_data(name=msg.text.strip())
    await msg.answer("💰 <b>Narxini</b> yozing (so'mda):\nMasalan: 150000")
    await state.set_state(AddItem.price)

@dp.message(AddItem.price)
async def got_price(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    try:
        p = int(msg.text.strip().replace(" ","").replace(",",""))
        await state.update_data(price=p)
        await msg.answer("💸 <b>Eski narxini</b> yozing (chegirma uchun):\n<i>Chegirma yo'q bo'lsa 0</i>")
        await state.set_state(AddItem.old_price)
    except:
        await msg.answer("❌ Faqat raqam! Masalan: 150000")

@dp.message(AddItem.old_price)
async def got_old(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    try:
        o = int(msg.text.strip().replace(" ","").replace(",",""))
        await state.update_data(old_price=o)
        await msg.answer("📝 <b>Tavsif</b> yozing:\nMasalan: 100% paxta, yuqori sifat\n\n<i>Tavsif yo'q bo'lsa 0</i>")
        await state.set_state(AddItem.desc)
    except:
        await msg.answer("❌ Faqat raqam!")

@dp.message(AddItem.desc)
async def got_desc(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    desc = "" if msg.text.strip() == "0" else msg.text.strip()
    await state.update_data(description=desc)
    await msg.answer(
        "📏 <b>O'lchamlarni</b> yozing (vergul bilan):\nMasalan: XS,S,M,L,XL,XXL\n\n<i>O'lcham yo'q bo'lsa 0</i>")
    await state.set_state(AddItem.sizes)

@dp.message(AddItem.sizes)
async def got_sizes(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    sizes = "" if msg.text.strip() == "0" else msg.text.strip().upper()
    await state.update_data(sizes=sizes)
    await msg.answer(
        "🎨 <b>Ranglarni</b> yozing (vergul bilan):\nMasalan: Qora,Oq,Ko'k,Qizil\n\n<i>Rang yo'q bo'lsa 0</i>")
    await state.set_state(AddItem.colors)

@dp.message(AddItem.colors)
async def got_colors(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    colors = "" if msg.text.strip() == "0" else msg.text.strip()
    await state.update_data(colors=colors)
    await msg.answer("🏷️ <b>Badge tanlang:</b>", reply_markup=badge_kb())
    await state.set_state(AddItem.stock)

@dp.callback_query(F.data.startswith("b_"), AddItem.stock)
async def got_badge(call: CallbackQuery, state: FSMContext):
    if call.from_user.id != ADMIN_ID: return
    await state.update_data(badge=call.data[2:])
    await call.message.answer("📂 <b>Kategoriya tanlang:</b>", reply_markup=cat_kb())
    await state.set_state(AddItem.category)

@dp.callback_query(F.data.startswith("cat_"), AddItem.category)
async def got_cat(call: CallbackQuery, state: FSMContext):
    if call.from_user.id != ADMIN_ID: return
    await state.update_data(category_id=int(call.data[4:]))
    await call.message.answer("📦 <b>Stok miqdori</b> yozing:\nMasalan: 50\n<i>Cheksiz bo'lsa 9999</i>")
    await state.set_state(AddItem.name)
    # reuse name state for stock
    await state.set_state(State())
    await state.update_data(step="stock")
    await state.set_state(AddItem.name)

@dp.callback_query(F.data.startswith("cat_"))
async def got_cat_final(call: CallbackQuery, state: FSMContext):
    if call.from_user.id != ADMIN_ID: return
    data = await state.get_data()
    if data.get("step") == "awaiting_cat":
        await state.update_data(category_id=int(call.data[4:]), step="stock")
        await call.message.answer("📦 <b>Stok miqdori:</b>")
        await state.set_state(AddItem.stock)

@dp.message(AddItem.category)
async def got_stock_final(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    try: stock = int(msg.text.strip())
    except: await msg.answer("❌ Raqam yozing!"); return
    await save_product(msg, state, stock)

async def save_product(msg, state, stock):
    data   = await state.get_data()
    photos = data.get("photos", [])
    img    = photos[0]["url"] if photos else ""
    fid    = photos[0]["file_id"] if photos else ""
    name   = data.get("name","")
    price  = data.get("price",0)
    old    = data.get("old_price",0)
    desc   = data.get("description","")
    badge  = data.get("badge","NEW")
    cat_id = data.get("category_id",1)
    sizes  = data.get("sizes","S,M,L,XL")
    colors = data.get("colors","")

    conn = db(); cur = conn.cursor()
    cur.execute("""INSERT INTO products(category_id,name,description,price,old_price,
        image,badge,stock,active,rating,sold_count,sizes,colors,created_at)
        VALUES(?,?,?,?,?,?,?,?,1,4.5,0,?,?,?)""",
        (cat_id,name,desc,price,old,img,badge,stock,sizes,colors,now()))
    pid = cur.lastrowid
    conn.commit(); conn.close()

    disc = round((1-price/old)*100) if old > price > 0 else 0
    caption = (
        f"✅ <b>Qo'shildi! #{pid}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"👗 <b>{name}</b>\n"
        f"💰 {fmt(price)} so'm" +
        (f" | 💸 {fmt(old)} so'm (-{disc}%)" if disc else "") +
        (f"\n📝 {desc}" if desc else "") +
        (f"\n📏 {sizes}" if sizes else "") +
        (f"\n🎨 {colors}" if colors else "") +
        f"\n🏷️ {badge} | 📦 {stock} ta | 🖼 {len(photos)} media"
    )
    try:
        if fid:
            await msg.answer_photo(fid, caption=caption)
        else:
            await msg.answer(caption)
    except:
        await msg.answer(caption)

    await msg.answer("🎉 Do'konga qo'shildi!", reply_markup=admin_kb())
    await state.clear()

# ── ADMIN: BUYURTMALAR ────────────────────────────────────────────────────────
@dp.message(F.text == "📦 Buyurtmalar")
async def admin_orders(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    conn = db()
    rows = conn.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 10").fetchall()
    conn.close()
    if not rows: await msg.answer("📭 Buyurtma yo'q"); return
    for r in rows:
        o = dict(r)
        await msg.answer(order_text(o, True), reply_markup=order_kb(o["id"], o["status"]))

@dp.callback_query(F.data.startswith("o_"))
async def order_cb(call: CallbackQuery, state: FSMContext):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌", show_alert=True); return
    parts  = call.data.split("_")
    action = parts[1]
    oid    = int(parts[2])

    if action == "reply":
        await state.update_data(reply_oid=oid)
        await call.message.answer(
            f"💬 <b>#{oid} buyurtma egasiga xabar yozing:</b>",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="❌ Bekor", callback_data="cancel_reply")]
            ])
        )
        await state.set_state(OrdReply.msg)
        return

    smap = {"confirm":"confirmed","cancel":"cancelled","deliver":"delivering","done":"delivered"}
    ns = smap.get(action)
    if not ns: return
    conn = db()
    conn.execute("UPDATE orders SET status=? WHERE id=?", (ns, oid))
    conn.commit()
    order = dict(conn.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone())
    conn.close()
    em, lb = STATUS.get(ns, ("❓",""))
    await call.answer(f"{em} {lb}!", show_alert=True)
    await call.message.edit_reply_markup(reply_markup=order_kb(oid, ns))
    tg_uid = order.get("tg_user_id")
    if tg_uid:
        msgs = {
            "confirmed":  f"✅ <b>Buyurtma #{oid} tasdiqlandi!</b>\nAdmin tez orada bog'lanadi.",
            "delivering": f"🚚 <b>Buyurtma #{oid} yo'lda!</b>",
            "delivered":  f"🎉 <b>Buyurtma #{oid} yetkazildi!</b>\nRahmat! Yana keling!",
            "cancelled":  f"❌ <b>Buyurtma #{oid} bekor qilindi.</b>\nSavol: {SUPPORT}",
        }
        if ns in msgs:
            try: await bot.send_message(int(tg_uid), msgs[ns])
            except: pass

@dp.callback_query(F.data == "cancel_reply")
async def cancel_reply(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.delete()

@dp.message(OrdReply.msg)
async def send_reply(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    data = await state.get_data()
    oid  = data.get("reply_oid")
    conn = db()
    order = conn.execute("SELECT tg_user_id FROM orders WHERE id=?", (oid,)).fetchone()
    conn.close()
    if not order: await msg.answer("❌"); await state.clear(); return
    try:
        await bot.send_message(int(order["tg_user_id"]),
            f"💬 <b>{SHOP_NAME} admini:</b>\n\n{msg.text}\n\n<i>Buyurtma #{oid}</i>")
        await msg.answer("✅ Yuborildi!", reply_markup=admin_kb())
    except:
        await msg.answer("❌ Yetmadi", reply_markup=admin_kb())
    await state.clear()

# ── ADMIN: STATISTIKA ─────────────────────────────────────────────────────────
@dp.message(F.text == "📊 Statistika")
async def stats(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    conn  = db()
    today = datetime.now().strftime("%Y-%m-%d")
    p     = conn.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0]
    u     = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    o     = conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    new_o = conn.execute("SELECT COUNT(*) FROM orders WHERE status='new'").fetchone()[0]
    t_o   = conn.execute("SELECT COUNT(*) FROM orders WHERE created_at LIKE ?", (today+"%",)).fetchone()[0]
    t_r   = conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE created_at LIKE ? AND status!='cancelled'", (today+"%",)).fetchone()[0]
    tot_r = conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status='delivered'").fetchone()[0]
    conn.close()
    await msg.answer(
        f"📊 <b>{SHOP_NAME} — Statistika</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"👗 Mahsulotlar: <b>{p} ta</b>\n"
        f"👥 Mijozlar: <b>{u} ta</b>\n"
        f"📋 Jami buyurtmalar: <b>{o} ta</b>\n"
        f"🆕 Yangi: <b>{new_o} ta</b>\n"
        f"📅 Bugun: <b>{t_o} ta buyurtma</b>\n\n"
        f"💰 Bugungi daromad: <b>{fmt(t_r)} so'm</b>\n"
        f"💎 Jami daromad: <b>{fmt(tot_r)} so'm</b>",
        reply_markup=admin_kb()
    )

# ── ADMIN: BROADCAST ──────────────────────────────────────────────────────────
@dp.message(F.text == "📢 Broadcast")
async def bc_start(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    conn  = db()
    count = conn.execute("SELECT COUNT(*) FROM users WHERE blocked=0").fetchone()[0]
    conn.close()
    await msg.answer(
        f"📢 <b>Broadcast</b>\n{count} ta foydalanuvchiga yuboriladi\n\n"
        "Matn yoki rasm+caption yuboring:",
        reply_markup=ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="❌ Bekor")]], resize_keyboard=True)
    )
    await state.set_state(BC.msg)

@dp.message(F.text == "❌ Bekor")
async def cancel(msg: Message, state: FSMContext):
    await state.clear()
    if msg.from_user.id == ADMIN_ID:
        await msg.answer("❌ Bekor", reply_markup=admin_kb())
    else:
        await msg.answer("❌ Bekor", reply_markup=user_kb())

@dp.message(BC.msg)
async def do_bc(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    text    = msg.text or msg.caption or ""
    photo   = msg.photo[-1].file_id if msg.photo else None
    conn    = db()
    users   = conn.execute("SELECT tg_user_id FROM users WHERE blocked=0").fetchall()
    conn.close()
    sent = failed = 0
    prog = await msg.answer(f"📤 0/{len(users)}")
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🛍 Do'konni ochish", web_app=WebAppInfo(url=WEB_URL))
    ]])
    for i, u in enumerate(users):
        try:
            uid = int(u["tg_user_id"])
            if photo:
                await bot.send_photo(uid, photo, caption=text, reply_markup=kb)
            else:
                await bot.send_message(uid, text, reply_markup=kb)
            sent += 1
        except: failed += 1
        if (i+1) % 20 == 0:
            try: await prog.edit_text(f"📤 {i+1}/{len(users)}")
            except: pass
        await asyncio.sleep(0.05)
    await prog.edit_text(f"✅ Yuborildi: {sent}\n❌ Xato: {failed}")
    await msg.answer("Tugadi!", reply_markup=admin_kb())
    await state.clear()

# ── ADMIN: PROMO ──────────────────────────────────────────────────────────────
@dp.message(F.text == "🏷️ Promo kod")
async def promo_list(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    conn   = db()
    promos = conn.execute("SELECT * FROM promo_codes ORDER BY id DESC LIMIT 10").fetchall()
    conn.close()
    text = "🏷️ <b>Promo kodlar</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
    for p in promos:
        s = "✅" if p["active"] else "❌"
        text += f"{s} <code>{p['code']}</code> — {p['discount_percent']}% | {p['used_count']}/{p['max_uses']}\n"
    text += "\n<b>Yangi:</b> <code>/promo KOD FOIZ MAKS</code>"
    await msg.answer(text, reply_markup=admin_kb())

@dp.message(Command("promo"))
async def make_promo(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    p = msg.text.split()
    if len(p) < 3: await msg.answer("Format: /promo KOD FOIZ MAKS"); return
    try:
        code = p[1].upper(); disc = int(p[2]); maks = int(p[3]) if len(p) > 3 else 100
    except: await msg.answer("❌ Xato format"); return
    conn = db(); cur = conn.cursor()
    try:
        cur.execute("INSERT INTO promo_codes(code,discount_percent,max_uses,active,created_at) VALUES(?,?,?,1,?)",
                    (code, disc, maks, now()))
        conn.commit()
        await msg.answer(f"✅ Promo yaratildi!\n🏷️ <code>{code}</code> — {disc}% | {maks} ta")
    except: await msg.answer("❌ Bu kod mavjud!")
    conn.close()

# ── ADMIN: O'CHIRISH ──────────────────────────────────────────────────────────
@dp.message(F.text == "🗑 Mahsulot o'chirish")
async def del_menu(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    conn  = db()
    prods = conn.execute("SELECT id,name,price FROM products WHERE active=1 ORDER BY id DESC LIMIT 20").fetchall()
    conn.close()
    if not prods: await msg.answer("📭 Mahsulot yo'q"); return
    kb = InlineKeyboardBuilder()
    for p in prods:
        kb.button(text=f"🗑 #{p['id']} {p['name'][:20]}", callback_data=f"del_{p['id']}")
    kb.adjust(1)
    await msg.answer("🗑 O'chirish uchun tanlang:", reply_markup=kb.as_markup())

@dp.callback_query(F.data.startswith("del_"))
async def del_prod(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID: return
    pid  = int(call.data[4:])
    conn = db()
    prod = conn.execute("SELECT name FROM products WHERE id=?", (pid,)).fetchone()
    conn.execute("UPDATE products SET active=0 WHERE id=?", (pid,))
    conn.commit(); conn.close()
    await call.answer(f"✅ O'chirildi: {prod['name'] if prod else ''}", show_alert=True)
    await call.message.edit_reply_markup(reply_markup=None)

# ── ADMIN: MIJOZLAR ───────────────────────────────────────────────────────────
@dp.message(F.text == "👥 Mijozlar")
async def admin_users(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    conn  = db()
    total = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    users = conn.execute("SELECT * FROM users ORDER BY id DESC LIMIT 10").fetchall()
    conn.close()
    text = f"👥 <b>Mijozlar ({total} ta)</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
    for u in users:
        fname = u["full_name"] or "Noma'lum"
        text += f"👤 <b>{fname}</b>"
        if u["username"]: text += f" @{u['username']}"
        text += f" | ⭐{fmt(u['points'])} | 📦{u['orders_count']}\n"
    await msg.answer(text, reply_markup=admin_kb())

# ── WEB APP DATA ──────────────────────────────────────────────────────────────
@dp.message(F.web_app_data)
async def webapp(msg: Message):
    try: data = json.loads(msg.web_app_data.data)
    except: return
    oid   = data.get("order_id","?")
    total = data.get("total",0)
    phone = data.get("phone","")
    fname = data.get("full_name","")
    await msg.answer(
        f"✅ <b>Buyurtma #{oid} qabul qilindi!</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"💰 Jami: <b>{fmt(total)} so'm</b>\n📞 {phone}\n\n"
        f"⏳ Admin tez orada bog'lanadi!\n{SUPPORT}",
        reply_markup=user_kb()
    )
    if oid != "?":
        conn = db()
        order = conn.execute("SELECT * FROM orders WHERE id=?", (int(oid),)).fetchone()
        conn.close()
        if order:
            o = dict(order)
            try:
                await bot.send_message(ADMIN_ID,
                    "🆕 <b>YANGI BUYURTMA!</b>\n" + order_text(o, True),
                    reply_markup=order_kb(int(oid), "new"))
            except: pass
            try:
                await bot.send_message(CHANNEL,
                    f"🛒 <b>YANGI BUYURTMA #{oid}</b>\n"
                    f"👗 {fname}\n📞 <code>{phone}</code>\n"
                    f"💰 <b>{fmt(total)} so'm</b>")
            except: pass
            tg_uid = o.get("tg_user_id","")
            if tg_uid:
                pts = max(1, total//1000)
                conn2 = db()
                conn2.execute("UPDATE users SET total_spent=total_spent+?,orders_count=orders_count+1,points=points+? WHERE tg_user_id=?",
                              (total, pts, tg_uid))
                conn2.commit(); conn2.close()

# ── MAIN ──────────────────────────────────────────────────────────────────────
async def main():
    init_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
