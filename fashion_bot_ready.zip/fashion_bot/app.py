import os, sqlite3, json, secrets, random, string
from datetime import datetime
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from functools import wraps

DB_NAME        = os.getenv("DB_NAME", "fashion.db")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")
SECRET_KEY     = os.getenv("SECRET_KEY", secrets.token_hex(32))
SHOP_NAME      = os.getenv("SHOP_NAME", "FASHION STORE")
SUPPORT        = os.getenv("SUPPORT", "@support")

app = Flask(__name__)
app.secret_key = SECRET_KEY

def db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def init_db():
    conn = db(); c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS categories(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE, icon TEXT DEFAULT '👗', sort_order INTEGER DEFAULT 0)""")
    c.execute("""CREATE TABLE IF NOT EXISTS products(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER DEFAULT 1,
        name TEXT NOT NULL, description TEXT DEFAULT '',
        price INTEGER NOT NULL, old_price INTEGER DEFAULT 0,
        image TEXT DEFAULT '', badge TEXT DEFAULT 'NEW',
        stock INTEGER DEFAULT 99, active INTEGER DEFAULT 1,
        rating REAL DEFAULT 4.5, sold_count INTEGER DEFAULT 0,
        sizes TEXT DEFAULT '', colors TEXT DEFAULT '',
        created_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_user_id TEXT, full_name TEXT, phone TEXT,
        items TEXT, total INTEGER, status TEXT DEFAULT 'new',
        note TEXT DEFAULT '', size TEXT DEFAULT '',
        color TEXT DEFAULT '', promo_code TEXT DEFAULT '',
        discount INTEGER DEFAULT 0, created_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS banners(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT, subtitle TEXT, color TEXT DEFAULT '#6c2bff',
        badge TEXT DEFAULT '', active INTEGER DEFAULT 1)""")
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_user_id TEXT UNIQUE, full_name TEXT, username TEXT,
        referral_code TEXT UNIQUE, referred_by TEXT DEFAULT '',
        points INTEGER DEFAULT 0, orders_count INTEGER DEFAULT 0,
        total_spent INTEGER DEFAULT 0, blocked INTEGER DEFAULT 0,
        joined_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS promo_codes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE, discount_percent INTEGER DEFAULT 10,
        max_uses INTEGER DEFAULT 100, used_count INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1, created_at TEXT)""")

    c.execute("SELECT COUNT(*) FROM categories")
    if c.fetchone()[0] == 0:
        cats = [("Ayollar kiyimi","👗",1),("Erkaklar kiyimi","👔",2),
                ("Bolalar kiyimi","🧒",3),("Sport kiyim","🏋️",4),
                ("Poyabzal","👟",5),("Aksessuarlar","💍",6)]
        c.executemany("INSERT INTO categories(name,icon,sort_order) VALUES(?,?,?)", cats)

    c.execute("SELECT COUNT(*) FROM banners")
    if c.fetchone()[0] == 0:
        c.executemany("INSERT INTO banners(title,subtitle,color,badge) VALUES(?,?,?,?)", [
            ("Yangi kolleksiya!","Trend kiyimlar yetib keldi","#6c2bff","NEW"),
            ("Mega chegirma!","Barcha kiyimlarga -30%","#ff5f7e","SALE"),
            ("VIP mijozlar uchun","Maxsus narxlar va bonuslar","#ff9f43","VIP"),
        ])

    c.execute("SELECT COUNT(*) FROM promo_codes")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO promo_codes(code,discount_percent,max_uses,active,created_at) VALUES(?,?,?,?,?)",
                  ("FASHION10", 10, 1000, 1, now()))

    conn.commit(); conn.close()

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("admin"):
            if request.is_json: return jsonify({"error":"Unauthorized"}), 401
            return redirect(url_for("admin_login"))
        return f(*args, **kwargs)
    return decorated

# ── PAGES ─────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html", shop_name=SHOP_NAME, support=SUPPORT)

@app.route("/admin/login", methods=["GET","POST"])
def admin_login():
    error = None
    if request.method == "POST":
        if request.form.get("password","") == ADMIN_PASSWORD:
            session["admin"] = True
            return redirect(url_for("admin_page"))
        error = "Parol noto'g'ri"
    return render_template("login.html", error=error)

@app.route("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("admin_login"))

@app.route("/admin")
@admin_required
def admin_page():
    return render_template("admin.html", shop_name=SHOP_NAME)

# ── PUBLIC API ────────────────────────────────────────────────────────────────
@app.route("/api/config")
def api_config():
    return jsonify({"shop_name": SHOP_NAME, "support": SUPPORT})

@app.route("/api/banners")
def api_banners():
    conn = db()
    rows = conn.execute("SELECT * FROM banners WHERE active=1").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/categories")
def api_categories():
    conn = db()
    rows = conn.execute("SELECT * FROM categories ORDER BY sort_order").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/products")
def api_products():
    q        = request.args.get("q","").strip().lower()
    category = request.args.get("category","")
    badge    = request.args.get("badge","")
    sort     = request.args.get("sort","newest")
    limit    = min(int(request.args.get("limit",60)),200)
    offset   = int(request.args.get("offset",0))

    conn = db()
    sql = """SELECT p.*, c.name as cat_name, c.icon as cat_icon
        FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.active=1"""
    params = []
    if category: sql += " AND c.name=?"; params.append(category)
    if badge:    sql += " AND p.badge=?"; params.append(badge)
    if q:        sql += " AND (LOWER(p.name) LIKE ? OR LOWER(p.description) LIKE ?)"; params += [f"%{q}%",f"%{q}%"]
    order = {"newest":"p.id DESC","popular":"p.sold_count DESC","price_asc":"p.price ASC","price_desc":"p.price DESC","rating":"p.rating DESC"}
    sql += f" ORDER BY {order.get(sort,'p.id DESC')} LIMIT ? OFFSET ?"; params += [limit,offset]
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/products/<int:pid>")
def api_product(pid):
    conn = db()
    row = conn.execute("""SELECT p.*, c.name as cat_name FROM products p
        LEFT JOIN categories c ON p.category_id=c.id WHERE p.id=? AND p.active=1""", (pid,)).fetchone()
    conn.close()
    if not row: return jsonify({"error":"Not found"}), 404
    return jsonify(dict(row))

@app.route("/api/promo", methods=["POST"])
def api_promo():
    code = (request.json or {}).get("code","").strip().upper()
    conn = db()
    p = conn.execute("SELECT * FROM promo_codes WHERE code=? AND active=1", (code,)).fetchone()
    conn.close()
    if not p: return jsonify({"ok":False,"error":"Promo kod topilmadi"})
    if p["max_uses"] > 0 and p["used_count"] >= p["max_uses"]:
        return jsonify({"ok":False,"error":"Promo kod tugagan"})
    return jsonify({"ok":True,"discount":p["discount_percent"],"code":code})

@app.route("/api/register-user", methods=["POST"])
def api_register():
    data  = request.json or {}
    tg_id = str(data.get("tg_id",""))
    if not tg_id: return jsonify({"ok":False})
    conn = db(); cur = conn.cursor()
    ex = conn.execute("SELECT referral_code,points FROM users WHERE tg_user_id=?", (tg_id,)).fetchone()
    if not ex:
        rc = ''.join(random.choices(string.ascii_uppercase+string.digits, k=8))
        cur.execute("INSERT INTO users(tg_user_id,full_name,username,referral_code,referred_by,joined_at) VALUES(?,?,?,?,?,?)",
                    (tg_id, data.get("name",""), data.get("username",""), rc, data.get("ref",""), now()))
        conn.commit()
        user = conn.execute("SELECT * FROM users WHERE tg_user_id=?", (tg_id,)).fetchone()
    else:
        user = conn.execute("SELECT * FROM users WHERE tg_user_id=?", (tg_id,)).fetchone()
    conn.close()
    return jsonify({"ok":True,"ref_code":user["referral_code"],"points":user["points"]})

@app.route("/api/order", methods=["POST"])
def api_order():
    data  = request.json or {}
    items = data.get("items",[])
    if not items: return jsonify({"ok":False,"error":"Savat bo'sh"}), 400
    total    = int(data.get("total",0))
    user     = data.get("user") or {}
    phone    = data.get("phone","").strip()
    full_name= data.get("full_name","").strip() or user.get("first_name","")
    if not phone: return jsonify({"ok":False,"error":"Telefon kerak"}), 400

    promo_code = data.get("promo_code","").strip().upper()
    discount   = 0
    conn = db(); cur = conn.cursor()
    if promo_code:
        p = conn.execute("SELECT * FROM promo_codes WHERE code=? AND active=1", (promo_code,)).fetchone()
        if p:
            discount = p["discount_percent"]
            cur.execute("UPDATE promo_codes SET used_count=used_count+1 WHERE code=?", (promo_code,))

    final = int(total * (1 - discount/100))

    for item in items:
        cur.execute("UPDATE products SET stock=MAX(0,stock-?),sold_count=sold_count+? WHERE id=?",
                    (item.get("qty",1), item.get("qty",1), item.get("id")))

    cur.execute("""INSERT INTO orders(tg_user_id,full_name,phone,items,total,status,note,promo_code,discount,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (str(user.get("id","")), full_name, phone,
         json.dumps(items, ensure_ascii=False), final, "new",
         data.get("note",""), promo_code, discount, now()))
    order_id = cur.lastrowid

    tg_id = str(user.get("id",""))
    if tg_id:
        pts = max(1, final//1000)
        cur.execute("UPDATE users SET total_spent=total_spent+?,orders_count=orders_count+1,points=points+? WHERE tg_user_id=?",
                    (final, pts, tg_id))

    conn.commit(); conn.close()
    return jsonify({"ok":True,"order_id":order_id,"discount":discount,"final_total":final})

# ── ADMIN API ─────────────────────────────────────────────────────────────────
@app.route("/api/admin/stats")
@admin_required
def api_admin_stats():
    conn  = db()
    today = datetime.now().strftime("%Y-%m-%d")
    s = {
        "products": conn.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0],
        "users":    conn.execute("SELECT COUNT(*) FROM users").fetchone()[0],
        "orders":   conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0],
        "new_orders":conn.execute("SELECT COUNT(*) FROM orders WHERE status='new'").fetchone()[0],
        "today":    conn.execute("SELECT COUNT(*) FROM orders WHERE created_at LIKE ?", (today+"%",)).fetchone()[0],
        "today_rev":conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE created_at LIKE ? AND status!='cancelled'",(today+"%",)).fetchone()[0],
        "revenue":  conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status='delivered'").fetchone()[0],
    }
    conn.close()
    return jsonify(s)

@app.route("/api/admin/products")
@admin_required
def api_admin_products():
    conn = db()
    rows = conn.execute("""SELECT p.*,c.name as cat_name FROM products p
        LEFT JOIN categories c ON p.category_id=c.id ORDER BY p.id DESC""").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/admin/add-product", methods=["POST"])
@admin_required
def api_add_product():
    d = request.json or {}
    if not d.get("name"): return jsonify({"ok":False,"error":"Nom kerak"}), 400
    conn = db(); cur = conn.cursor()
    cur.execute("""INSERT INTO products(category_id,name,description,price,old_price,image,badge,stock,active,rating,sold_count,sizes,colors,created_at)
        VALUES(?,?,?,?,?,?,?,?,1,4.5,0,?,?,?)""",
        (int(d.get("category_id",1)), d.get("name"), d.get("description",""),
         int(d.get("price",0)), int(d.get("old_price",0)),
         d.get("image",""), d.get("badge","NEW"),
         int(d.get("stock",99)), d.get("sizes","S,M,L,XL"), d.get("colors",""), now()))
    pid = cur.lastrowid; conn.commit(); conn.close()
    return jsonify({"ok":True,"id":pid})

@app.route("/api/admin/edit-product", methods=["POST"])
@admin_required
def api_edit_product():
    d = request.json or {}
    if not d.get("id"): return jsonify({"ok":False}), 400
    conn = db()
    conn.execute("""UPDATE products SET category_id=?,name=?,description=?,price=?,old_price=?,
        image=?,badge=?,stock=?,active=?,sizes=?,colors=? WHERE id=?""",
        (int(d.get("category_id",1)), d.get("name"), d.get("description",""),
         int(d.get("price",0)), int(d.get("old_price",0)),
         d.get("image",""), d.get("badge",""), int(d.get("stock",0)),
         int(d.get("active",1)), d.get("sizes",""), d.get("colors",""), d.get("id")))
    conn.commit(); conn.close()
    return jsonify({"ok":True})

@app.route("/api/admin/delete-product", methods=["POST"])
@admin_required
def api_delete_product():
    d = request.json or {}
    conn = db()
    conn.execute("UPDATE products SET active=0 WHERE id=?", (d.get("id"),))
    conn.commit(); conn.close()
    return jsonify({"ok":True})

@app.route("/api/admin/orders")
@admin_required
def api_admin_orders():
    status = request.args.get("status","")
    conn = db()
    sql = "SELECT * FROM orders"
    params = []
    if status: sql += " WHERE status=?"; params.append(status)
    sql += " ORDER BY id DESC LIMIT 200"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/admin/order-status", methods=["POST"])
@admin_required
def api_order_status():
    d = request.json or {}
    conn = db()
    conn.execute("UPDATE orders SET status=? WHERE id=?", (d.get("status"), d.get("id")))
    conn.commit(); conn.close()
    return jsonify({"ok":True})

@app.route("/api/admin/categories")
@admin_required
def api_admin_cats():
    conn = db()
    rows = conn.execute("SELECT * FROM categories ORDER BY sort_order").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/admin/users")
@admin_required
def api_admin_users():
    conn = db()
    rows = conn.execute("SELECT * FROM users ORDER BY id DESC LIMIT 500").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/admin/promos")
@admin_required
def api_admin_promos():
    conn = db()
    rows = conn.execute("SELECT * FROM promo_codes ORDER BY id DESC").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/admin/add-promo", methods=["POST"])
@admin_required
def api_add_promo():
    d = request.json or {}
    code = d.get("code","").strip().upper()
    if not code: return jsonify({"ok":False,"error":"Kod kerak"}), 400
    conn = db(); cur = conn.cursor()
    try:
        cur.execute("INSERT INTO promo_codes(code,discount_percent,max_uses,active,created_at) VALUES(?,?,?,1,?)",
                    (code, int(d.get("discount",10)), int(d.get("max_uses",100)), now()))
        conn.commit()
    except: conn.close(); return jsonify({"ok":False,"error":"Bu kod mavjud"})
    conn.close()
    return jsonify({"ok":True})

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=False)
