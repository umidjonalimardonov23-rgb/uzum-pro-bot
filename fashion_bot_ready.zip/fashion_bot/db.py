import sqlite3, os, json, random, string
from datetime import datetime

DB = os.getenv("DB_NAME", "fashion.db")

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def init():
    c = conn(); cur = c.cursor()
    cur.executescript("""
    CREATE TABLE IF NOT EXISTS products(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT DEFAULT '',
        price INTEGER NOT NULL,
        old_price INTEGER DEFAULT 0,
        media TEXT DEFAULT '',
        media_type TEXT DEFAULT 'photo',
        sizes TEXT DEFAULT '',
        colors TEXT DEFAULT '',
        badge TEXT DEFAULT '',
        stock INTEGER DEFAULT 99,
        active INTEGER DEFAULT 1,
        sold INTEGER DEFAULT 0,
        rating REAL DEFAULT 0,
        rating_count INTEGER DEFAULT 0,
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_id TEXT, name TEXT, phone TEXT,
        items TEXT, total INTEGER,
        size TEXT DEFAULT '', color TEXT DEFAULT '',
        status TEXT DEFAULT 'new',
        note TEXT DEFAULT '',
        promo TEXT DEFAULT '', discount INTEGER DEFAULT 0,
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_id TEXT UNIQUE, name TEXT, username TEXT,
        ref_code TEXT UNIQUE, referred_by TEXT DEFAULT '',
        points INTEGER DEFAULT 0,
        spent INTEGER DEFAULT 0,
        orders INTEGER DEFAULT 0,
        vip INTEGER DEFAULT 0,
        blocked INTEGER DEFAULT 0,
        joined TEXT
    );
    CREATE TABLE IF NOT EXISTS promos(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE,
        discount INTEGER DEFAULT 10,
        max_uses INTEGER DEFAULT 100,
        used INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1,
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS reviews(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER, tg_id TEXT, name TEXT,
        stars INTEGER DEFAULT 5, text TEXT DEFAULT '',
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS banners(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT, subtitle TEXT,
        color TEXT DEFAULT '#1a1a2e',
        active INTEGER DEFAULT 1
    );
    """)
    # seed
    cur.execute("SELECT COUNT(*) FROM promos")
    if cur.fetchone()[0] == 0:
        cur.execute("INSERT INTO promos(code,discount,max_uses,active,created_at) VALUES('FASHION10',10,1000,1,?)", (now(),))
    cur.execute("SELECT COUNT(*) FROM banners")
    if cur.fetchone()[0] == 0:
        cur.executemany("INSERT INTO banners(title,subtitle,color) VALUES(?,?,?)", [
            ("Yangi Kolleksiya","2026 bahor-yoz trendlari","#1a1a2e"),
            ("Mega Chegirma","Barcha kiyimlarga -30%","#8B0000"),
            ("Premium Kiyimlar","Yuqori sifat, qulay narx","#0d3b66"),
        ])
    cur.execute("SELECT COUNT(*) FROM products")
    if cur.fetchone()[0] == 0:
        products = [
            ("Oversize Hoodie","Yumshoq fleece material, unisex dizayn. Kuz-qish mavsumi uchun ideal.",189000,250000,"https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800&q=90","photo","XS,S,M,L,XL,XXL","Qora,Oq,Kulrang,Navy","NEW",50),
            ("Slim Jeans","Stretch denim, klassik kesim, barcha tanalar uchun.",159000,220000,"https://images.unsplash.com/photo-1542272454315-4c01d7abdf4a?w=800&q=90","photo","28,30,32,34,36","Ko'k,Qora,Kulrang","HOT",80),
            ("Oversize T-Shirt","100% paxta, premium sifat, trend bo'yinbog' dizayn.",89000,120000,"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&q=90","photo","S,M,L,XL,XXL","Oq,Qora,Yashil,Qizil,Ko'k","SALE",150),
            ("Bomber Jacket","Satin material, ichki qoplamali, stylish dizayn.",350000,450000,"https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=800&q=90","photo","S,M,L,XL","Qora,Yashil,Ko'k","TOP",30),
            ("Cargo Pants","Ko'p cho'ntakli, qulay material, street style.",220000,290000,"https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=800&q=90","photo","28,30,32,34,36","Xaki,Qora,Kulrang","NEW",60),
            ("Knit Sweater","Yumshoq trikotaj, issiq saqlaydi, elegant ko'rinish.",280000,350000,"https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=800&q=90","photo","S,M,L,XL","Krem,Ko'k,Yashil,Qizil","HOT",40),
            ("Jogger Pants","Sport uslubi, qulay material, kundalik kiyim uchun.",120000,160000,"https://images.unsplash.com/photo-1552902865-b72c031ac5ea?w=800&q=90","photo","S,M,L,XL,XXL","Qora,Kulrang,Navy","NEW",100),
            ("Denim Jacket","Klassik ko'k denim, har qanday kiyim bilan mos.",299000,380000,"https://images.unsplash.com/photo-1551537482-f2075a1d41f2?w=800&q=90","photo","S,M,L,XL","Ko'k,Qora","SALE",25),
        ]
        for p in products:
            cur.execute("""INSERT INTO products(name,description,price,old_price,media,media_type,sizes,colors,badge,stock,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (*p, now()))
    c.commit(); c.close()

def get_user(tg_id):
    c = conn()
    r = c.execute("SELECT * FROM users WHERE tg_id=?", (str(tg_id),)).fetchone()
    c.close()
    return dict(r) if r else None

def reg_user(tg_id, name, username, ref=""):
    c = conn(); cur = c.cursor()
    if not c.execute("SELECT id FROM users WHERE tg_id=?", (str(tg_id),)).fetchone():
        rc = ''.join(random.choices(string.ascii_uppercase+string.digits, k=8))
        cur.execute("INSERT INTO users(tg_id,name,username,ref_code,referred_by,joined) VALUES(?,?,?,?,?,?)",
                    (str(tg_id), name, username or "", rc, ref, now()))
        if ref:
            cur.execute("UPDATE users SET points=points+300 WHERE ref_code=?", (ref,))
        c.commit()
    c.close()
