import os
import sqlite3
import json
import hashlib
import secrets
from datetime import datetime
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, abort
from functools import wraps

# ── Config ──────────────────────────────────────────────────────────────────
DB_NAME        = os.getenv("DB_NAME", "uzum_market.db")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "change_this_password")
SECRET_KEY     = os.getenv("SECRET_KEY", secrets.token_hex(32))
SHOP_NAME      = os.getenv("SHOP_NAME", "UZUM MARKET")
SUPPORT        = os.getenv("SUPPORT", "@support")
BOT_TOKEN      = os.getenv("BOT_TOKEN", "")

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

# ── Database ─────────────────────────────────────────────────────────────────
def db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def init_db():
    conn = db()
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS categories(
        id   INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        icon TEXT DEFAULT '🛍',
        sort_order INTEGER DEFAULT 0
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS products(
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER,
        name        TEXT NOT NULL,
        description TEXT,
        price       INTEGER NOT NULL,
        old_price   INTEGER DEFAULT 0,
        image       TEXT,
        badge       TEXT DEFAULT '',
        stock       INTEGER DEFAULT 99,
        active      INTEGER DEFAULT 1,
        rating      REAL DEFAULT 4.5,
        sold_count  INTEGER DEFAULT 0,
        created_at  TEXT
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS orders(
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_user_id  TEXT,
        full_name   TEXT,
        phone       TEXT,
        address     TEXT,
        items       TEXT,
        total       INTEGER,
        payment     TEXT DEFAULT 'card',
        status      TEXT DEFAULT 'new',
        note        TEXT DEFAULT '',
        created_at  TEXT
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS banners(
        id       INTEGER PRIMARY KEY AUTOINCREMENT,
        title    TEXT,
        subtitle TEXT,
        color    TEXT DEFAULT '#7c2cff',
        badge    TEXT DEFAULT '',
        active   INTEGER DEFAULT 1
    )""")

    # Seed categories
    cur.execute("SELECT COUNT(*) FROM categories")
    if cur.fetchone()[0] == 0:
        cats = [
            ("Elektronika", "📱", 1),
            ("Kiyim",       "👕", 2),
            ("Uy-ro'zg'or","🏠", 3),
            ("Go'zallik",   "💄", 4),
            ("Sovg'alar",   "🎁", 5),
            ("Aksiyalar",   "🔥", 6),
            ("Bolalar",     "🧸", 7),
            ("Sport",       "🏋️", 8),
        ]
        cur.executemany("INSERT INTO categories(name,icon,sort_order) VALUES(?,?,?)", cats)

    # Seed products
    cur.execute("SELECT COUNT(*) FROM products")
    if cur.fetchone()[0] == 0:
        products = [
            (1, "Redmi Buds 4 Pro",    "Kuchli bass, ANC, 36 soat batareya. Bluetooth 5.3 quloqchin.",     189000, 230000, "/static/img/p1.svg",  "CHEGIRMA", 50, 4.8, 1240),
            (1, "Smart Watch X9 Ultra","42mm AMOLED, GPS, SpO2, yurak urishi, IP68 suv bardosh.",           249000, 310000, "/static/img/p2.svg",  "TOP",      30, 4.7,  890),
            (1, "Power Bank 20000mAh", "65W tez quvvatlash, LCD ko'rsatgich, 3 USB port.",                  159000, 199000, "/static/img/p3.svg",  "NEW",      80, 4.6,  567),
            (2, "Oversize Futbolka",   "100% paxta, trend dizayn, S-XXL o'lcham.",                          79000,  99000, "/static/img/p4.svg",  "SALE",    200, 4.5,  320),
            (2, "Premium Hoodie",      "Qalin fleece, kengaytirilgan qo'ltiq, unisex.",                     179000, 230000, "/static/img/p5.svg",  "HOT",      60, 4.9,  445),
            (3, "Smart LED Chiroq",    "RGB, Wi-Fi, ovozli boshqaruv, 16 mln rang.",                        35000,  45000, "/static/img/p6.svg",  "SALE",    150, 4.4,  780),
            (3, "Mini Blender 800W",   "8 tishli po'lat pichoq, BPA-free idish, 600ml.",                   149000, 199000, "/static/img/p7.svg",  "NEW",      40, 4.7,  234),
            (4, "Parfyum Classic EDP", "Frantsuz formulasi, 100ml, 24 soat davomlilik.",                    119000, 150000, "/static/img/p8.svg",  "HIT",      70, 4.6,  567),
            (5, "Premium Sovg'a Seti", "5 xil mahsulot, chiroyli qadoqlash, har qanday bayram uchun.",     199000, 299000, "/static/img/p9.svg",  "GIFT",     25, 4.8,  189),
            (8, "Fitness Rezinka Seti","5 xil qattiqlık, lateks material, sumkali.",                        49000,  65000, "/static/img/p10.svg", "SPORT",   120, 4.5,  430),
            (7, "Lego Konstruktor",    "520 detal, 6-12 yosh uchun, rivojlantiruvchi.",                     89000, 120000, "/static/img/p11.svg", "KIDS",     35, 4.9,  210),
            (6, "Mega Aksiya To'plam", "5 mahsulot bir qadoqda, 40% chegirma.",                            199000, 299000, "/static/img/p12.svg", "MEGA",     15, 4.7,  678),
        ]
        cur.executemany("""
            INSERT INTO products(category_id,name,description,price,old_price,image,badge,stock,rating,sold_count,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)
        """, [(c,n,d,p,o,img,b,st,r,s,now()) for c,n,d,p,o,img,b,st,r,s in products])

    # Seed banners
    cur.execute("SELECT COUNT(*) FROM banners")
    if cur.fetchone()[0] == 0:
        banners = [
            ("Mega chegirmalar!", "Barcha elektronikalarga -30%", "#7c2cff", "CHEGIRMA"),
            ("Yangi kolleksiya",  "Kiyim va aksessuarlar yetib keldi", "#ff6b35", "NEW"),
            ("Sovg'a mavsumi",    "Yaqinlaringizni xursand qiling", "#00c853", "GIFT"),
        ]
        cur.executemany("INSERT INTO banners(title,subtitle,color,badge) VALUES(?,?,?,?)", banners)

    conn.commit()
    conn.close()

# ── Auth helpers ─────────────────────────────────────────────────────────────
def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("admin"):
            if request.is_json:
                return jsonify({"error": "Unauthorized"}), 401
            return redirect(url_for("admin_login"))
        return f(*args, **kwargs)
    return decorated

# ── Pages ────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html", shop_name=SHOP_NAME, support=SUPPORT)

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    error = None
    if request.method == "POST":
        pwd = request.form.get("password", "")
        if pwd == ADMIN_PASSWORD:
            session["admin"] = True
            return redirect(url_for("admin_page"))
        error = "Parol noto'g'ri"
    return render_template("login.html", error=error)

@app.route("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("admin_login"))

@app.route("/admin")
@admin_required
def admin_page():
    return render_template("admin.html", shop_name=SHOP_NAME)

# ── Public API ────────────────────────────────────────────────────────────────
@app.route("/api/config")
def api_config():
    return jsonify({"shop_name": SHOP_NAME, "support": SUPPORT, "currency": "so'm"})

@app.route("/api/banners")
def api_banners():
    conn = db()
    rows = conn.execute("SELECT * FROM banners WHERE active=1").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/categories")
def api_categories():
    conn = db()
    rows = conn.execute("SELECT * FROM categories ORDER BY sort_order").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/products")
def api_products():
    q        = request.args.get("q", "").strip().lower()
    category = request.args.get("category", "")
    badge    = request.args.get("badge", "")
    sort     = request.args.get("sort", "newest")  # newest | price_asc | price_desc | rating | popular
    limit    = min(int(request.args.get("limit", 50)), 100)
    offset   = int(request.args.get("offset", 0))

    conn = db()
    sql = """
        SELECT p.*, c.name as category_name, c.icon as category_icon
        FROM products p
        LEFT JOIN categories c ON p.category_id=c.id
        WHERE p.active=1
    """
    params = []

    if category:
        sql += " AND c.name=?"
        params.append(category)
    if badge:
        sql += " AND p.badge=?"
        params.append(badge)
    if q:
        sql += " AND (LOWER(p.name) LIKE ? OR LOWER(p.description) LIKE ?)"
        params.extend([f"%{q}%", f"%{q}%"])

    order_map = {
        "newest":     "p.id DESC",
        "price_asc":  "p.price ASC",
        "price_desc": "p.price DESC",
        "rating":     "p.rating DESC",
        "popular":    "p.sold_count DESC",
    }
    sql += f" ORDER BY {order_map.get(sort, 'p.id DESC')} LIMIT ? OFFSET ?"
    params.extend([limit, offset])

    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/products/<int:pid>")
def api_product_detail(pid):
    conn = db()
    row = conn.execute("""
        SELECT p.*, c.name as category_name, c.icon as category_icon
        FROM products p LEFT JOIN categories c ON p.category_id=c.id
        WHERE p.id=? AND p.active=1
    """, (pid,)).fetchone()
    conn.close()
    if not row:
        return jsonify({"error": "Not found"}), 404
    return jsonify(dict(row))

@app.route("/api/order", methods=["POST"])
def api_order():
    data  = request.json or {}
    items = data.get("items", [])
    if not items:
        return jsonify({"ok": False, "error": "Savat bo'sh"}), 400

    total = int(data.get("total", 0))
    user  = data.get("user") or {}
    phone = data.get("phone", "").strip()
    full_name = data.get("full_name", "").strip() or user.get("first_name", "")
    addr  = data.get("address", "Admin bog'lanadi")

    if not phone:
        return jsonify({"ok": False, "error": "Telefon kerak"}), 400

    conn = db()
    cur = conn.cursor()

    # Decrease stock
    for item in items:
        cur.execute("UPDATE products SET stock=MAX(0,stock-?), sold_count=sold_count+? WHERE id=?",
                    (item.get("qty", 1), item.get("qty", 1), item.get("id")))

    cur.execute("""
        INSERT INTO orders(tg_user_id,full_name,phone,address,items,total,payment,status,note,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?)
    """, (
        str(user.get("id", "")),
        full_name,
        phone, addr,
        json.dumps(items, ensure_ascii=False),
        total,
        data.get("payment", "naqd"),
        "new",
        data.get("note", ""),
        now(),
    ))
    order_id = cur.lastrowid
    conn.commit()
    conn.close()
    return jsonify({"ok": True, "order_id": order_id})

# ── Admin API (all protected) ────────────────────────────────────────────────
@app.route("/api/admin/stats")
@admin_required
def api_admin_stats():
    conn = db()
    users    = conn.execute("SELECT COUNT(DISTINCT tg_user_id) FROM orders").fetchone()[0]
    products = conn.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0]
    orders   = conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    revenue  = conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status!='cancelled'").fetchone()[0]
    new_ord  = conn.execute("SELECT COUNT(*) FROM orders WHERE status='new'").fetchone()[0]
    today    = conn.execute("SELECT COUNT(*) FROM orders WHERE created_at LIKE ?", (datetime.now().strftime("%Y-%m-%d") + "%",)).fetchone()[0]
    conn.close()
    return jsonify({"users": users, "products": products, "orders": orders,
                    "revenue": revenue, "new_orders": new_ord, "today": today})

@app.route("/api/admin/orders")
@admin_required
def api_admin_orders():
    status = request.args.get("status", "")
    conn = db()
    sql = "SELECT * FROM orders"
    params = []
    if status:
        sql += " WHERE status=?"
        params.append(status)
    sql += " ORDER BY id DESC LIMIT 200"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/admin/order-status", methods=["POST"])
@admin_required
def api_admin_order_status():
    data = request.json or {}
    allowed = {"new", "confirmed", "delivering", "delivered", "cancelled"}
    status = data.get("status", "new")
    if status not in allowed:
        return jsonify({"ok": False, "error": "Noto'g'ri status"}), 400
    conn = db()
    conn.execute("UPDATE orders SET status=? WHERE id=?", (status, data.get("id")))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})

@app.route("/api/admin/products")
@admin_required
def api_admin_products():
    conn = db()
    rows = conn.execute("""
        SELECT p.*, c.name as category_name
        FROM products p LEFT JOIN categories c ON p.category_id=c.id
        ORDER BY p.id DESC
    """).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/admin/add-product", methods=["POST"])
@admin_required
def api_admin_add_product():
    data = request.json or {}
    name = data.get("name", "").strip()
    if not name:
        return jsonify({"ok": False, "error": "Nom kerak"}), 400
    conn = db()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO products(category_id,name,description,price,old_price,image,badge,stock,active,rating,sold_count,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        int(data.get("category_id", 1)),
        name,
        data.get("description", ""),
        int(data.get("price", 0)),
        int(data.get("old_price", 0)),
        data.get("image", "/static/img/p1.svg"),
        data.get("badge", "NEW"),
        int(data.get("stock", 99)),
        1, 4.5, 0, now(),
    ))
    new_id = cur.lastrowid
    conn.commit()
    conn.close()
    return jsonify({"ok": True, "id": new_id})

@app.route("/api/admin/edit-product", methods=["POST"])
@admin_required
def api_admin_edit_product():
    data = request.json or {}
    pid = data.get("id")
    if not pid:
        return jsonify({"ok": False}), 400
    conn = db()
    conn.execute("""
        UPDATE products SET category_id=?,name=?,description=?,price=?,old_price=?,
        image=?,badge=?,stock=?,active=? WHERE id=?
    """, (
        int(data.get("category_id", 1)),
        data.get("name", ""),
        data.get("description", ""),
        int(data.get("price", 0)),
        int(data.get("old_price", 0)),
        data.get("image", ""),
        data.get("badge", ""),
        int(data.get("stock", 0)),
        int(data.get("active", 1)),
        pid,
    ))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})

@app.route("/api/admin/delete-product", methods=["POST"])
@admin_required
def api_admin_delete_product():
    data = request.json or {}
    conn = db()
    conn.execute("UPDATE products SET active=0 WHERE id=?", (data.get("id"),))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})

@app.route("/api/admin/categories")
@admin_required
def api_admin_categories():
    conn = db()
    rows = conn.execute("SELECT * FROM categories ORDER BY sort_order").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=False)
