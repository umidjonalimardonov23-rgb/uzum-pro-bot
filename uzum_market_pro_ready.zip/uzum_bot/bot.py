import os
import asyncio
import json
import sqlite3
from datetime import datetime

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    Message,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    WebAppInfo,
    CallbackQuery,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

# ── Config (always from env) ─────────────────────────────────────────────────
BOT_TOKEN   = os.environ["BOT_TOKEN"]
ADMIN_ID    = int(os.environ["ADMIN_ID"])
WEB_APP_URL = os.environ["WEB_APP_URL"]
SHOP_NAME   = os.getenv("SHOP_NAME", "UZUM MARKET")
SUPPORT     = os.getenv("SUPPORT", "@support")
DB_NAME     = os.getenv("DB_NAME", "uzum_market.db")

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp  = Dispatcher()

# ── DB helpers ───────────────────────────────────────────────────────────────
def get_order(order_id: int):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    row = conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    conn.close()
    return dict(row) if row else None

def get_stats():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    stats = {
        "total_orders":   conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0],
        "new_orders":     conn.execute("SELECT COUNT(*) FROM orders WHERE status='new'").fetchone()[0],
        "revenue":        conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status!='cancelled'").fetchone()[0],
        "users":          conn.execute("SELECT COUNT(DISTINCT tg_user_id) FROM orders").fetchone()[0],
        "products":       conn.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0],
        "today_orders":   conn.execute("SELECT COUNT(*) FROM orders WHERE created_at LIKE ?",
                                       (datetime.now().strftime("%Y-%m-%d") + "%",)).fetchone()[0],
    }
    conn.close()
    return stats

def set_order_status(order_id: int, status: str):
    conn = sqlite3.connect(DB_NAME)
    conn.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
    conn.commit()
    conn.close()

def get_recent_orders(limit=10):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    rows = conn.execute("SELECT * FROM orders ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

# ── Keyboards ────────────────────────────────────────────────────────────────
def main_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"🛒 {SHOP_NAME} ni ochish", web_app=WebAppInfo(url=WEB_APP_URL))],
        [
            InlineKeyboardButton(text="📞 Yordam", url=f"https://t.me/{SUPPORT.lstrip('@')}"),
            InlineKeyboardButton(text="📢 Kanal",  url=f"https://t.me/{SUPPORT.lstrip('@')}"),
        ],
    ])

def order_action_keyboard(order_id: int, status: str):
    kb = InlineKeyboardBuilder()
    if status == "new":
        kb.button(text="✅ Tasdiqlash",   callback_data=f"ord_confirm_{order_id}")
        kb.button(text="❌ Bekor qilish", callback_data=f"ord_cancel_{order_id}")
    elif status == "confirmed":
        kb.button(text="🚚 Yetkazishda",  callback_data=f"ord_deliver_{order_id}")
        kb.button(text="❌ Bekor qilish", callback_data=f"ord_cancel_{order_id}")
    elif status == "delivering":
        kb.button(text="✅ Yetkazildi",   callback_data=f"ord_done_{order_id}")
    kb.adjust(2)
    return kb.as_markup()

def admin_main_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Statistika",    callback_data="admin_stats")],
        [InlineKeyboardButton(text="📦 Yangi buyurtmalar", callback_data="admin_new_orders")],
        [InlineKeyboardButton(text="📋 So'ngi buyurtmalar", callback_data="admin_recent_orders")],
        [InlineKeyboardButton(text="🌐 Web Admin Panel", url=f"{WEB_APP_URL}/admin")],
    ])

# ── Status helpers ───────────────────────────────────────────────────────────
STATUS_LABELS = {
    "new":        ("🆕", "Yangi"),
    "confirmed":  ("✅", "Tasdiqlangan"),
    "delivering": ("🚚", "Yetkazilmoqda"),
    "delivered":  ("🎉", "Yetkazildi"),
    "cancelled":  ("❌", "Bekor qilindi"),
}

def fmt_price(n):
    return f"{int(n or 0):,}".replace(",", " ") + " so'm"

def order_text(o: dict, admin=False) -> str:
    emoji, label = STATUS_LABELS.get(o.get("status", "new"), ("❓", "Noma'lum"))
    try:
        items = json.loads(o.get("items", "[]"))
    except Exception:
        items = []

    items_text = ""
    for item in items[:5]:
        items_text += f"  • {item.get('name', '?')} × {item.get('qty', 1)} — {fmt_price(item.get('price', 0) * item.get('qty', 1))}\n"
    if len(items) > 5:
        items_text += f"  ... va yana {len(items)-5} ta\n"

    text = (
        f"{emoji} <b>Buyurtma #{o['id']}</b> — <b>{label}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
    )
    if admin:
        text += f"👤 Telegram ID: <code>{o.get('tg_user_id', '-')}</code>\n"
    text += (
        f"🙋 Ism Familiya: <b>{o.get('full_name', o.get('full_name', 'Ko\'rsatilmagan'))}</b>\n"
        f"📞 Telefon: <code>{o.get('phone', '-')}</code>\n"
    )
    if o.get("note"):
        text += f"💬 Izoh: {o['note']}\n"
    text += f"\n🛍 Mahsulotlar:\n{items_text}\n"
    text += f"💰 <b>Jami: {fmt_price(o.get('total', 0))}</b>\n"
    text += f"🕐 {o.get('created_at', '')}"
    return text

# ── Handlers ──────────────────────────────────────────────────────────────────
@dp.message(CommandStart())
async def cmd_start(message: Message):
    name = message.from_user.first_name or "Siz"
    await message.answer(
        f"👋 Xush kelibsiz, <b>{name}</b>!\n\n"
        f"🛍 <b>{SHOP_NAME}</b> — O'zbekistoning eng qulay online bozori\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "🔥 <b>Nima bor?</b>\n"
        "  📱 Elektronika\n"
        "  👕 Kiyim-kechak\n"
        "  🏠 Uy-ro'zg'or buyumlari\n"
        "  💄 Go'zallik mahsulotlari\n"
        "  🎁 Sovg'alar va boshqalar\n\n"
        "👇 <b>Do'konni ochish uchun tugmani bosing:</b>",
        reply_markup=main_keyboard(),
    )

@dp.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(
        "ℹ️ <b>Yordam</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "🛒 Buyurtma berish:\n"
        "  1. Do'konni oching\n"
        "  2. Mahsulot tanlang\n"
        "  3. Savatga qo'shing\n"
        "  4. Checkout qiling\n\n"
        "📦 Buyurtma statusi:\n"
        "  🆕 Yangi → ✅ Tasdiqlangan → 🚚 Yetkazilmoqda → 🎉 Yetkazildi\n\n"
        f"📞 Muammo bo'lsa: {SUPPORT}",
        reply_markup=main_keyboard(),
    )

@dp.message(Command("orders"))
async def cmd_orders(message: Message):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT * FROM orders WHERE tg_user_id=? ORDER BY id DESC LIMIT 5",
        (str(message.from_user.id),)
    ).fetchall()
    conn.close()

    if not rows:
        await message.answer(
            "📦 Sizda hali buyurtma yo'q.\n\nDo'konni oching va birinchi buyurtmangizni bering! 🛒",
            reply_markup=main_keyboard(),
        )
        return

    await message.answer(f"📦 <b>Sizning so'ngi {len(rows)} ta buyurtmangiz:</b>")
    for o in rows:
        await message.answer(order_text(dict(o)))

@dp.message(Command("admin"))
async def cmd_admin(message: Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("❌ Siz admin emassiz.")
        return
    stats = get_stats()
    await message.answer(
        f"⚙️ <b>Admin Panel — {SHOP_NAME}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"📊 Bugungi buyurtmalar: <b>{stats['today_orders']}</b>\n"
        f"🆕 Yangi buyurtmalar: <b>{stats['new_orders']}</b>\n"
        f"👥 Foydalanuvchilar: <b>{stats['users']}</b>\n"
        f"💰 Umumiy daromad: <b>{fmt_price(stats['revenue'])}</b>",
        reply_markup=admin_main_keyboard(),
    )

# ── Web App order received ────────────────────────────────────────────────────
@dp.message(F.web_app_data)
async def on_web_app_data(message: Message):
    try:
        data = json.loads(message.web_app_data.data)
    except Exception:
        data = {}

    order_id = data.get("order_id", "?")
    total    = data.get("total", 0)
    phone    = data.get("phone", "-")
    addr     = data.get("address", "-")

    # Confirm to user
    await message.answer(
        f"✅ <b>Buyurtmangiz qabul qilindi!</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"🔖 Buyurtma №: <b>{order_id}</b>\n"
        f"💰 Jami: <b>{fmt_price(total)}</b>\n"
        f"📞 Telefon: <code>{phone}</code>\n"
        f"📍 Manzil: {addr}\n\n"
        "⏳ Operatorimiz tez orada siz bilan bog'lanadi!\n"
        f"📞 Savol bo'lsa: {SUPPORT}",
    )

    # Notify admin
    if order_id != "?":
        order = get_order(int(order_id))
        if order:
            await bot.send_message(
                ADMIN_ID,
                "🆕 <b>YANGI BUYURTMA!</b>\n" + order_text(order, admin=True),
                reply_markup=order_action_keyboard(int(order_id), "new"),
            )

# ── Admin Callback handlers ───────────────────────────────────────────────────
@dp.callback_query(F.data == "admin_stats")
async def cb_admin_stats(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌ Ruxsat yo'q", show_alert=True)
        return
    stats = get_stats()
    await call.message.edit_text(
        f"📊 <b>Statistika — {SHOP_NAME}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"📦 Jami buyurtmalar: <b>{stats['total_orders']}</b>\n"
        f"🆕 Yangi: <b>{stats['new_orders']}</b>\n"
        f"📅 Bugun: <b>{stats['today_orders']}</b>\n"
        f"👥 Foydalanuvchilar: <b>{stats['users']}</b>\n"
        f"🛍 Mahsulotlar: <b>{stats['products']}</b>\n"
        f"💰 Daromad: <b>{fmt_price(stats['revenue'])}</b>",
        reply_markup=admin_main_keyboard(),
    )
    await call.answer()

@dp.callback_query(F.data == "admin_new_orders")
async def cb_admin_new_orders(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌", show_alert=True)
        return
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    rows = conn.execute("SELECT * FROM orders WHERE status='new' ORDER BY id DESC LIMIT 10").fetchall()
    conn.close()
    if not rows:
        await call.answer("✅ Yangi buyurtmalar yo'q!", show_alert=True)
        return
    await call.answer()
    for row in rows:
        o = dict(row)
        await call.message.answer(
            order_text(o, admin=True),
            reply_markup=order_action_keyboard(o["id"], o["status"]),
        )

@dp.callback_query(F.data == "admin_recent_orders")
async def cb_admin_recent(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌", show_alert=True)
        return
    orders = get_recent_orders(10)
    await call.answer()
    for o in orders:
        await call.message.answer(
            order_text(o, admin=True),
            reply_markup=order_action_keyboard(o["id"], o["status"]),
        )

@dp.callback_query(F.data.startswith("ord_"))
async def cb_order_action(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌ Ruxsat yo'q", show_alert=True)
        return

    parts = call.data.split("_")
    action   = parts[1]
    order_id = int(parts[2])

    status_map = {
        "confirm": "confirmed",
        "cancel":  "cancelled",
        "deliver": "delivering",
        "done":    "delivered",
    }

    new_status = status_map.get(action)
    if not new_status:
        await call.answer("❓ Noma'lum amal", show_alert=True)
        return

    set_order_status(order_id, new_status)
    order = get_order(order_id)

    emoji, label = STATUS_LABELS.get(new_status, ("✅", new_status))
    await call.answer(f"{emoji} {label}!", show_alert=True)

    # Update admin message
    await call.message.edit_text(
        order_text(order, admin=True),
        reply_markup=order_action_keyboard(order_id, new_status),
    )

    # Notify user about status change
    tg_uid = order.get("tg_user_id")
    if tg_uid and tg_uid.isdigit():
        user_msgs = {
            "confirmed":  f"✅ Buyurtma №{order_id} <b>tasdiqlandi!</b> Tez orada yo'lga chiqamiz 🚚",
            "delivering": f"🚚 Buyurtma №{order_id} <b>yo'lda!</b> Kuryer siz bilan bog'lanadi.",
            "delivered":  f"🎉 Buyurtma №{order_id} <b>yetkazildi!</b> Xaridingiz uchun rahmat! 🛍",
            "cancelled":  f"❌ Buyurtma №{order_id} <b>bekor qilindi.</b> Savol bo'lsa {SUPPORT} ga yozing.",
        }
        msg = user_msgs.get(new_status)
        if msg:
            try:
                await bot.send_message(int(tg_uid), msg, reply_markup=main_keyboard())
            except Exception:
                pass

# ── Run ───────────────────────────────────────────────────────────────────────
async def main():
    print(f"🚀 {SHOP_NAME} bot ishga tushdi...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
