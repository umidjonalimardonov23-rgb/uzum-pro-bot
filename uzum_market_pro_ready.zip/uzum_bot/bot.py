import os, asyncio, json, sqlite3, random, string, aiohttp
from datetime import datetime
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo, CallbackQuery, FSInputFile
from aiogram.utils.keyboard import InlineKeyboardBuilder

BOT_TOKEN   = os.environ["BOT_TOKEN"]
ADMIN_ID    = int(os.environ["ADMIN_ID"])
WEB_APP_URL = os.environ["WEB_APP_URL"]
SHOP_NAME   = os.getenv("SHOP_NAME", "UZUM MARKET")
SUPPORT     = os.getenv("SUPPORT", "@support")
DB_NAME     = os.getenv("DB_NAME", "uzum_market.db")
CHANNEL_ID  = os.getenv("CHANNEL_ID", "@UZUM_AMAZON")

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp  = Dispatcher()

def db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def fmt(n):
    return f"{int(n):,}".replace(",", " ")

STATUS_LABELS = {
    "new": ("🆕","Yangi"), "confirmed": ("✅","Tasdiqlangan"),
    "delivering": ("🚚","Yetkazilmoqda"), "delivered": ("🎉","Yetkazildi"),
    "cancelled": ("❌","Bekor"),
}

def main_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"🛍 {SHOP_NAME} ni ochish", web_app=WebAppInfo(url=WEB_APP_URL))],
        [InlineKeyboardButton(text="📢 Kanal", url=f"https://t.me/{CHANNEL_ID.lstrip('@')}"),
         InlineKeyboardButton(text="📞 Yordam", url=f"https://t.me/{SUPPORT.lstrip('@')}")],
        [InlineKeyboardButton(text="👥 Do'stni taklif qil", callback_data="my_referral"),
         InlineKeyboardButton(text="🏆 Ballarim", callback_data="my_points")],
    ])

def channel_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"📢 {CHANNEL_ID} — Obuna bo'lish", url=f"https://t.me/{CHANNEL_ID.lstrip('@')}")],
        [InlineKeyboardButton(text="✅ Obuna bo'ldim", callback_data="check_sub")],
    ])

def admin_main_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Statistika", callback_data="admin_stats")],
        [InlineKeyboardButton(text="📦 Yangi buyurtmalar", callback_data="admin_new_orders"),
         InlineKeyboardButton(text="📋 Barchasi", callback_data="admin_recent_orders")],
        [InlineKeyboardButton(text="📢 Broadcast yuborish", callback_data="admin_broadcast")],
        [InlineKeyboardButton(text="🏷️ Promo kod yaratish", callback_data="admin_promo")],
        [InlineKeyboardButton(text="👥 Foydalanuvchilar", callback_data="admin_users")],
        [InlineKeyboardButton(text="🌐 Web Admin Panel", url=f"{WEB_APP_URL}/admin")],
    ])

def order_action_keyboard(order_id, status):
    kb = InlineKeyboardBuilder()
    if status == "new":
        kb.button(text="✅ Tasdiqlash", callback_data=f"ord_confirm_{order_id}")
        kb.button(text="❌ Bekor", callback_data=f"ord_cancel_{order_id}")
    elif status == "confirmed":
        kb.button(text="🚚 Yetkazishda", callback_data=f"ord_deliver_{order_id}")
        kb.button(text="❌ Bekor", callback_data=f"ord_cancel_{order_id}")
    elif status == "delivering":
        kb.button(text="🎉 Yetkazildi", callback_data=f"ord_done_{order_id}")
    kb.adjust(2)
    return kb.as_markup()

async def is_subscribed(user_id):
    try:
        member = await bot.get_chat_member(CHANNEL_ID, user_id)
        return member.status not in ("left", "kicked", "banned")
    except:
        return True

def get_order(order_id):
    conn = db()
    row = conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    conn.close()
    return dict(row) if row else None

def get_user(tg_id):
    conn = db()
    row = conn.execute("SELECT * FROM users WHERE tg_user_id=?", (str(tg_id),)).fetchone()
    conn.close()
    return dict(row) if row else None

def register_user(tg_id, name, username, ref=""):
    conn = db(); cur = conn.cursor()
    existing = conn.execute("SELECT * FROM users WHERE tg_user_id=?", (str(tg_id),)).fetchone()
    if not existing:
        ref_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        cur.execute("""INSERT INTO users(tg_user_id,full_name,username,referral_code,referred_by,joined_at)
            VALUES(?,?,?,?,?,?)""", (str(tg_id), name, username or "", ref_code, ref, now()))
        if ref:
            cur.execute("UPDATE users SET points=points+200 WHERE referral_code=?", (ref,))
        conn.commit()
    conn.close()

def order_text(o, admin=False):
    emoji, label = STATUS_LABELS.get(o.get("status","new"), ("❓","Noma'lum"))
    try: items = json.loads(o.get("items","[]"))
    except: items = []
    items_text = ""
    for item in items[:8]:
        items_text += f"  • {item.get('name','?')} × {item.get('qty',1)} — {fmt(item.get('price',0)*item.get('qty',1))} so'm\n"
    text = f"{emoji} <b>Buyurtma #{o['id']}</b> — <b>{label}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
    if admin:
        text += f"👤 TG ID: <code>{o.get('tg_user_id','-')}</code>\n"
    text += f"🙋 Ism: <b>{o.get('full_name','-')}</b>\n"
    text += f"📞 Telefon: <code>{o.get('phone','-')}</code>\n"
    if o.get("size"): text += f"📏 O'lcham: {o['size']}\n"
    if o.get("color"): text += f"🎨 Rang: {o['color']}\n"
    if o.get("promo_code"): text += f"🏷️ Promo: {o['promo_code']} (-{o.get('discount',0)}%)\n"
    if o.get("note"): text += f"💬 Izoh: {o['note']}\n"
    text += f"\n🛍 Mahsulotlar:\n{items_text}\n"
    text += f"💰 <b>Jami: {fmt(o.get('total',0))} so'm</b>\n"
    text += f"🕐 {o.get('created_at','')}"
    return text

# ── HANDLERS ──────────────────────────────────────────────────────────────────
@dp.message(CommandStart())
async def cmd_start(message: Message):
    name = message.from_user.first_name or "Siz"
    tg_id = message.from_user.id
    username = message.from_user.username or ""

    # Referral check
    args = message.text.split()
    ref = args[1] if len(args) > 1 and not args[1].startswith("order") else ""

    register_user(tg_id, name, username, ref)

    if tg_id == ADMIN_ID:
        await message.answer(
            f"👑 Salom, <b>Admin {name}</b>!\n\n"
            f"🛍 <b>{SHOP_NAME}</b> — Boshqaruv paneli\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Quyidagi funksiyalardan foydalaning:",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text=f"🛍 Do'konni ochish", web_app=WebAppInfo(url=WEB_APP_URL))],
                [InlineKeyboardButton(text="⚙️ Admin panel", callback_data="admin_menu")],
                [InlineKeyboardButton(text="📢 Broadcast", callback_data="admin_broadcast")],
                [InlineKeyboardButton(text="🌐 Web panel", url=f"{WEB_APP_URL}/admin")],
            ])
        )
        return

    subscribed = await is_subscribed(tg_id)
    if not subscribed:
        await message.answer(
            f"👋 Salom, <b>{name}</b>!\n\n"
            f"🔒 <b>{SHOP_NAME}</b> ga kirish uchun\n"
            f"avval kanalga obuna bo'ling!\n\n"
            f"📢 Kanalda: aksiyalar, yangi mahsulotlar,\nsovg'alar va boshqalar! 🎁",
            reply_markup=channel_keyboard()
        )
        return

    user = get_user(tg_id)
    points = user["points"] if user else 0
    vip = "👑 VIP" if (user and user["vip"]) else ""

    await message.answer(
        f"👋 Xush kelibsiz, <b>{name}</b>! {vip}\n\n"
        f"🛍 <b>{SHOP_NAME}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"⭐ Ballaringiz: <b>{fmt(points)}</b>\n\n"
        "🔥 Eng yaxshi narxlar!\n"
        "📦 Tez yetkazib berish!\n"
        "✅ Sifat kafolati!\n\n"
        "👇 Do'konni oching:",
        reply_markup=main_keyboard()
    )

@dp.callback_query(F.data == "check_sub")
async def cb_check_sub(call: CallbackQuery):
    if not await is_subscribed(call.from_user.id):
        await call.answer("❌ Hali obuna bo'lmagansiz!", show_alert=True)
        return
    await call.message.delete()
    name = call.from_user.first_name or "Siz"
    await call.message.answer(
        f"✅ Rahmat! Xush kelibsiz, <b>{name}</b>!\n\n"
        "🎁 Birinchi buyurtmangizga <b>UZUM10</b> promo kodini kiriting!\n"
        "10% chegirma olasiz! 🛒",
        reply_markup=main_keyboard()
    )

@dp.callback_query(F.data == "admin_menu")
async def cb_admin_menu(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌ Ruxsat yo'q", show_alert=True); return
    await call.message.edit_text(f"⚙️ <b>Admin Panel — {SHOP_NAME}</b>\n━━━━━━━━━━━━━━━━━━━━",
                                  reply_markup=admin_main_keyboard())

@dp.callback_query(F.data == "admin_stats")
async def cb_admin_stats(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌", show_alert=True); return
    conn = db()
    users    = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    orders   = conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    revenue  = conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status!='cancelled'").fetchone()[0]
    new_ord  = conn.execute("SELECT COUNT(*) FROM orders WHERE status='new'").fetchone()[0]
    today    = conn.execute("SELECT COUNT(*) FROM orders WHERE created_at LIKE ?", (datetime.now().strftime("%Y-%m-%d")+"%",)).fetchone()[0]
    today_r  = conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE created_at LIKE ? AND status!='cancelled'", (datetime.now().strftime("%Y-%m-%d")+"%",)).fetchone()[0]
    conn.close()
    await call.message.edit_text(
        f"📊 <b>Statistika — {SHOP_NAME}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"👥 Foydalanuvchilar: <b>{fmt(users)}</b>\n"
        f"📦 Jami buyurtmalar: <b>{fmt(orders)}</b>\n"
        f"🆕 Yangi: <b>{fmt(new_ord)}</b>\n"
        f"📅 Bugungi buyurtmalar: <b>{fmt(today)}</b>\n"
        f"💰 Bugungi daromad: <b>{fmt(today_r)} so'm</b>\n"
        f"💎 Jami daromad: <b>{fmt(revenue)} so'm</b>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 Orqaga", callback_data="admin_menu")]
        ])
    )

@dp.callback_query(F.data == "admin_new_orders")
async def cb_admin_new(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌", show_alert=True); return
    conn = db()
    rows = conn.execute("SELECT * FROM orders WHERE status='new' ORDER BY id DESC LIMIT 10").fetchall()
    conn.close()
    if not rows:
        await call.answer("Yangi buyurtma yo'q", show_alert=True); return
    await call.answer()
    for row in rows:
        o = dict(row)
        await call.message.answer(order_text(o, admin=True),
                                   reply_markup=order_action_keyboard(o["id"], o["status"]))

@dp.callback_query(F.data == "admin_recent_orders")
async def cb_admin_recent(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌", show_alert=True); return
    conn = db()
    rows = conn.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 5").fetchall()
    conn.close()
    if not rows:
        await call.answer("Buyurtma yo'q", show_alert=True); return
    await call.answer()
    for row in rows:
        o = dict(row)
        await call.message.answer(order_text(o, admin=True),
                                   reply_markup=order_action_keyboard(o["id"], o["status"]))

@dp.callback_query(F.data == "admin_users")
async def cb_admin_users(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌", show_alert=True); return
    conn = db()
    users = conn.execute("SELECT * FROM users ORDER BY id DESC LIMIT 10").fetchall()
    total = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    conn.close()
    text = f"👥 <b>Foydalanuvchilar ({fmt(total)} ta)</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
    for u in users:
        vip = "👑" if u["vip"] else "👤"
        text += f"{vip} <b>{u['full_name'] or 'Noma\\'lum'}</b> | ⭐{fmt(u['points'])} ball | 📦{u['orders_count']} buyurtma\n"
    await call.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="admin_menu")]
    ]))

@dp.callback_query(F.data == "admin_promo")
async def cb_admin_promo(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌", show_alert=True); return
    await call.message.edit_text(
        "🏷️ <b>Promo kod yaratish</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        "Quyidagi formatda yozing:\n\n"
        "<code>/promo KOD 15 500</code>\n\n"
        "KOD — promo kodi\n15 — chegirma foizi\n500 — maksimal foydalanish",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 Orqaga", callback_data="admin_menu")]
        ])
    )

@dp.message(Command("promo"))
async def cmd_promo(message: Message):
    if message.from_user.id != ADMIN_ID: return
    parts = message.text.split()
    if len(parts) < 3:
        await message.answer("❌ Format: /promo KOD FOIZ [MAX_FOYDALANISH]"); return
    code = parts[1].upper()
    discount = int(parts[2])
    max_uses = int(parts[3]) if len(parts) > 3 else 100
    conn = db(); cur = conn.cursor()
    try:
        cur.execute("INSERT INTO promo_codes(code,discount_percent,max_uses,active,created_at) VALUES(?,?,?,?,?)",
                    (code, discount, max_uses, 1, now()))
        conn.commit()
        await message.answer(f"✅ Promo kod yaratildi!\n\n🏷️ Kod: <code>{code}</code>\n💸 Chegirma: {discount}%\n👥 Max: {max_uses} ta")
    except:
        await message.answer("❌ Bu kod allaqachon mavjud")
    conn.close()

@dp.callback_query(F.data == "admin_broadcast")
async def cb_admin_broadcast(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌", show_alert=True); return
    await call.message.edit_text(
        "📢 <b>Broadcast yuborish</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        "Xabar matnini yozing:\n\n"
        "<code>/broadcast Xabar matni</code>\n\n"
        "Yoki rasm bilan yuboring:\n"
        "Rasm yuborib, caption ga /broadcast yozing",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 Orqaga", callback_data="admin_menu")]
        ])
    )

@dp.message(Command("broadcast"))
async def cmd_broadcast(message: Message):
    if message.from_user.id != ADMIN_ID: return
    text = message.text.replace("/broadcast", "").strip()
    if not text and not message.caption:
        await message.answer("❌ Matn yozing: /broadcast Xabar matni"); return

    msg_text = text or message.caption.replace("/broadcast","").strip()
    conn = db()
    users = conn.execute("SELECT tg_user_id FROM users WHERE blocked=0").fetchall()
    conn.close()

    sent = 0; failed = 0
    await message.answer(f"📤 Yuborilmoqda... {len(users)} ta foydalanuvchi")

    for u in users:
        try:
            if message.photo:
                await bot.send_photo(int(u["tg_user_id"]), message.photo[-1].file_id, caption=msg_text)
            else:
                await bot.send_message(int(u["tg_user_id"]), msg_text,
                                        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                                            [InlineKeyboardButton(text="🛍 Do'konni ochish", web_app=WebAppInfo(url=WEB_APP_URL))]
                                        ]))
            sent += 1
        except: failed += 1
        await asyncio.sleep(0.05)

    await message.answer(f"✅ Broadcast tugadi!\n✅ Yuborildi: {sent}\n❌ Xato: {failed}")

@dp.callback_query(F.data == "my_referral")
async def cb_referral(call: CallbackQuery):
    user = get_user(call.from_user.id)
    if not user:
        await call.answer("❌ Ro'yxatdan o'ting", show_alert=True); return
    ref_code = user["referral_code"]
    ref_link = f"https://t.me/{(await bot.get_me()).username}?start={ref_code}"
    conn = db()
    invited = conn.execute("SELECT COUNT(*) FROM referrals WHERE referrer_id=?", (str(call.from_user.id),)).fetchone()[0]
    conn.close()
    await call.message.answer(
        f"👥 <b>Referal tizimi</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"Do'stingizni taklif qiling va <b>200 ball</b> oling!\n\n"
        f"🔗 Sizning havolangiz:\n<code>{ref_link}</code>\n\n"
        f"👥 Taklif qilganlar: <b>{invited} ta</b>\n"
        f"⭐ Ballaringiz: <b>{fmt(user['points'])}</b>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📤 Ulashish", url=f"https://t.me/share/url?url={ref_link}&text=🛍 {SHOP_NAME} da chegirmalar bor! Obun bo'ling!")]
        ])
    )

@dp.callback_query(F.data == "my_points")
async def cb_points(call: CallbackQuery):
    user = get_user(call.from_user.id)
    if not user:
        await call.answer("❌", show_alert=True); return
    points = user["points"]
    vip = "👑 VIP mijoz" if user["vip"] else "Oddiy mijoz"
    await call.message.answer(
        f"🏆 <b>Sizning ballaringiz</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"⭐ Ballar: <b>{fmt(points)}</b>\n"
        f"👤 Status: <b>{vip}</b>\n"
        f"📦 Buyurtmalar: <b>{user['orders_count']}</b>\n"
        f"💰 Jami xarid: <b>{fmt(user['total_spent'])} so'm</b>\n\n"
        f"📌 Ball olish usullari:\n"
        f"  • Har 1000 so'm xarid = 1 ball\n"
        f"  • Do'st taklif = 200 ball\n"
        f"  • 500 000 so'm xarid = 👑 VIP\n\n"
        f"🎁 500 ball = 5 000 so'm chegirma!"
    )

@dp.callback_query(F.data.startswith("ord_"))
async def cb_order_action(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌ Ruxsat yo'q", show_alert=True); return
    parts = call.data.split("_")
    action = parts[1]
    order_id = int(parts[2])
    status_map = {"confirm":"confirmed","cancel":"cancelled","deliver":"delivering","done":"delivered"}
    new_status = status_map.get(action)
    if not new_status: return

    conn = db()
    conn.execute("UPDATE orders SET status=? WHERE id=?", (new_status, order_id))
    conn.commit()
    order = dict(conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone())
    conn.close()

    emoji, label = STATUS_LABELS.get(new_status, ("❓",""))
    await call.answer(f"{emoji} {label}!", show_alert=True)
    await call.message.edit_reply_markup(reply_markup=order_action_keyboard(order_id, new_status))

    # Notify user
    tg_uid = order.get("tg_user_id")
    if tg_uid:
        try:
            msgs = {"confirmed": f"✅ Buyurtma #{order_id} tasdiqlandi!\n📞 Admin tez orada bog'lanadi.",
                    "delivering": f"🚚 Buyurtma #{order_id} yo'lda!",
                    "delivered": f"🎉 Buyurtma #{order_id} yetkazildi!\n\nRahmat! ⭐ Do'konimizga qayta keling!",
                    "cancelled": f"❌ Buyurtma #{order_id} bekor qilindi.\nSavollar uchun: {SUPPORT}"}
            if new_status in msgs:
                await bot.send_message(int(tg_uid), msgs[new_status], reply_markup=main_keyboard())
        

@dp.message(F.web_app_data)
async def on_web_app_data(message: Message):
    try:
        data = json.loads(message.web_app_data.data)
    except: return

    order_id = data.get("order_id","?")
    total = data.get("total", 0)
    phone = data.get("phone","")
    full_name = data.get("full_name","")

    await message.answer(
        f"✅ <b>Buyurtma #{order_id} qabul qilindi!</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"💰 Jami: <b>{fmt(total)} so'm</b>\n"
        f"📞 {phone}\n\n"
        f"⏳ Admin tez orada bog'lanadi!\n"
        f"📞 Savol: {SUPPORT}",
        reply_markup=main_keyboard()
    )

    if order_id != "?":
        order = get_order(int(order_id))
        if order:
            msg_text = "🆕 <b>YANGI BUYURTMA!</b>\n" + order_text(order, admin=True)
            try:
                await bot.send_message(ADMIN_ID, msg_text,
                                        reply_markup=order_action_keyboard(int(order_id), "new"))
            
            try:
                await bot.send_message(CHANNEL_ID,
                    f"🛒 <b>YANGI BUYURTMA #{order_id}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"🙋 {order.get('full_name','-')}\n"
                    f"📞 <code>{order.get('phone','-')}</code>\n"
                    f"💰 <b>{fmt(order.get('total',0))} so'm</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"<i>{SHOP_NAME}</i>")
            

@dp.message(Command("admin"))
async def cmd_admin(message: Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("❌ Ruxsat yo'q"); return
    await message.answer(f"⚙️ <b>Admin Panel</b>", reply_markup=admin_main_keyboard())

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())

# Auto init DB on startup
import sys
sys.path.insert(0, os.path.dirname(__file__))
