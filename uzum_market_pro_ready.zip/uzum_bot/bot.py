import os, asyncio, json, sqlite3, random, string
from datetime import datetime
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from aiogram.types import (Message, InlineKeyboardMarkup, InlineKeyboardButton,
    WebAppInfo, CallbackQuery, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

# ── CONFIG ────────────────────────────────────────────────────────────────────
BOT_TOKEN  = os.environ["BOT_TOKEN"]
ADMIN_ID   = int(os.environ["ADMIN_ID"])
WEB_URL    = os.getenv("WEB_APP_URL", "https://uzum-pro-bot.onrender.com")
SHOP_NAME  = os.getenv("SHOP_NAME", "UZUM MARKET")
SUPPORT    = os.getenv("SUPPORT", "@support")
DB_NAME    = os.getenv("DB_NAME", "uzum_market.db")
CHANNEL    = os.getenv("CHANNEL_ID", "@UZUM_AMAZON")

bot     = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
storage = MemoryStorage()
dp      = Dispatcher(storage=storage)

# ── STATES ────────────────────────────────────────────────────────────────────
class AddProd(StatesGroup):
    photo     = State()
    name      = State()
    price     = State()
    old_price = State()
    desc      = State()
    badge     = State()
    stock     = State()
    category  = State()

class Broadcast(StatesGroup):
    msg = State()

class PromoCreate(StatesGroup):
    code     = State()
    discount = State()
    max_uses = State()

class OrderReply(StatesGroup):
    msg = State()

# ── DB ────────────────────────────────────────────────────────────────────────
def db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def fmt(n):
    try: return f"{int(n):,}".replace(",", " ")
    except: return str(n)

def init_db():
    conn = db(); c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS categories(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE, icon TEXT DEFAULT '🛍', sort_order INTEGER DEFAULT 0)""")
    c.execute("""CREATE TABLE IF NOT EXISTS products(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER DEFAULT 1,
        name TEXT NOT NULL, description TEXT DEFAULT '',
        price INTEGER NOT NULL, old_price INTEGER DEFAULT 0,
        image TEXT DEFAULT '', badge TEXT DEFAULT 'NEW',
        stock INTEGER DEFAULT 99, active INTEGER DEFAULT 1,
        rating REAL DEFAULT 4.5, sold_count INTEGER DEFAULT 0,
        sizes TEXT DEFAULT '', colors TEXT DEFAULT '',
        created_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_user_id TEXT, full_name TEXT, phone TEXT,
        items TEXT, total INTEGER, status TEXT DEFAULT 'new',
        note TEXT DEFAULT '', size TEXT DEFAULT '', color TEXT DEFAULT '',
        promo_code TEXT DEFAULT '', discount INTEGER DEFAULT 0,
        created_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_user_id TEXT UNIQUE, full_name TEXT, username TEXT,
        phone TEXT DEFAULT '', referral_code TEXT UNIQUE,
        referred_by TEXT DEFAULT '', points INTEGER DEFAULT 0,
        total_spent INTEGER DEFAULT 0, orders_count INTEGER DEFAULT 0,
        vip INTEGER DEFAULT 0, blocked INTEGER DEFAULT 0, joined_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS promo_codes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE, discount_percent INTEGER DEFAULT 10,
        max_uses INTEGER DEFAULT 100, used_count INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1, created_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS banners(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT, subtitle TEXT, color TEXT DEFAULT '#7c2cff',
        badge TEXT DEFAULT '', active INTEGER DEFAULT 1)""")

    c.execute("SELECT COUNT(*) FROM categories")
    if c.fetchone()[0] == 0:
        cats = [("Kiyim","👗",1),("Elektronika","📱",2),("Uy-ro'zg'or","🏠",3),
                ("Go'zallik","💄",4),("Sovg'alar","🎁",5),("Sport","🏋️",6),("Bolalar","🧸",7),("Boshqa","🛍",8)]
        c.executemany("INSERT INTO categories(name,icon,sort_order) VALUES(?,?,?)", cats)

    c.execute("SELECT COUNT(*) FROM promo_codes")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO promo_codes(code,discount_percent,max_uses,active,created_at) VALUES(?,?,?,?,?)",
                  ("UZUM10", 10, 1000, 1, now()))

    c.execute("SELECT COUNT(*) FROM banners")
    if c.fetchone()[0] == 0:
        c.executemany("INSERT INTO banners(title,subtitle,color,badge) VALUES(?,?,?,?)", [
            ("Mega chegirmalar!","Barcha mahsulotlarga -30%","#7c2cff","CHEGIRMA"),
            ("Yangi kolleksiya","Eng yangi mahsulotlar yetib keldi","#ff6b35","NEW"),
            ("Sovg'a mavsumi","Yaqinlaringizni xursand qiling","#00c853","GIFT"),
        ])
    conn.commit(); conn.close()

def get_user(tg_id):
    conn = db()
    r = conn.execute("SELECT * FROM users WHERE tg_user_id=?", (str(tg_id),)).fetchone()
    conn.close()
    return dict(r) if r else None

def reg_user(tg_id, name, username, ref=""):
    conn = db(); c = conn.cursor()
    ex = conn.execute("SELECT id FROM users WHERE tg_user_id=?", (str(tg_id),)).fetchone()
    if not ex:
        rc = ''.join(random.choices(string.ascii_uppercase+string.digits, k=8))
        c.execute("INSERT INTO users(tg_user_id,full_name,username,referral_code,referred_by,joined_at) VALUES(?,?,?,?,?,?)",
                  (str(tg_id), name, username or "", rc, ref, now()))
        if ref:
            c.execute("UPDATE users SET points=points+200 WHERE referral_code=?", (ref,))
        conn.commit()
    conn.close()

# ── KEYBOARDS ─────────────────────────────────────────────────────────────────
def main_kb():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="🛍 Do'konni ochish", web_app=WebAppInfo(url=WEB_URL))],
        [KeyboardButton(text="🛒 Buyurtmalarim"), KeyboardButton(text="🏆 Ballarim")],
        [KeyboardButton(text="👥 Do'stni taklif qil"), KeyboardButton(text="📞 Yordam")],
    ], resize_keyboard=True)

def admin_kb():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="➕ Mahsulot qo'shish")],
        [KeyboardButton(text="📦 Buyurtmalar"), KeyboardButton(text="📊 Statistika")],
        [KeyboardButton(text="📢 Broadcast"), KeyboardButton(text="🏷️ Promo kod")],
        [KeyboardButton(text="👥 Foydalanuvchilar"), KeyboardButton(text="❌ Mahsulot o'chirish")],
        [KeyboardButton(text="🛍 Do'konni ochish", web_app=WebAppInfo(url=WEB_URL))],
    ], resize_keyboard=True)

def badge_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔥 HOT",    callback_data="b_HOT"),
         InlineKeyboardButton(text="✨ NEW",    callback_data="b_NEW")],
        [InlineKeyboardButton(text="💸 SALE",   callback_data="b_SALE"),
         InlineKeyboardButton(text="⭐ TOP",    callback_data="b_TOP")],
        [InlineKeyboardButton(text="🎁 GIFT",   callback_data="b_GIFT"),
         InlineKeyboardButton(text="💎 VIP",    callback_data="b_VIP")],
        [InlineKeyboardButton(text="🏷️ Badge yo'q", callback_data="b_")],
    ])

def cat_kb():
    conn = db()
    cats = conn.execute("SELECT * FROM categories ORDER BY sort_order").fetchall()
    conn.close()
    kb = InlineKeyboardBuilder()
    for cat in cats:
        kb.button(text=f"{cat['icon']} {cat['name']}", callback_data=f"cat_{cat['id']}")
    kb.adjust(2)
    return kb.as_markup()

def order_kb(order_id, status):
    kb = InlineKeyboardBuilder()
    if status == "new":
        kb.button(text="✅ Tasdiqlash",  callback_data=f"o_confirm_{order_id}")
        kb.button(text="❌ Bekor qilish", callback_data=f"o_cancel_{order_id}")
    elif status == "confirmed":
        kb.button(text="🚚 Yo'lda",      callback_data=f"o_deliver_{order_id}")
        kb.button(text="❌ Bekor",        callback_data=f"o_cancel_{order_id}")
    elif status == "delivering":
        kb.button(text="🎉 Yetkazildi",  callback_data=f"o_done_{order_id}")
    kb.button(text="💬 Xabar yozish",    callback_data=f"o_reply_{order_id}")
    kb.adjust(2)
    return kb.as_markup()

STATUS = {
    "new":        ("🆕", "Yangi"),
    "confirmed":  ("✅", "Tasdiqlangan"),
    "delivering": ("🚚", "Yetkazilmoqda"),
    "delivered":  ("🎉", "Yetkazildi"),
    "cancelled":  ("❌", "Bekor"),
}

def order_text(o, admin=False):
    em, lb = STATUS.get(o.get("status","new"), ("❓","?"))
    try: items = json.loads(o.get("items","[]"))
    except: items = []
    lines = "".join(f"  • {i.get('name','?')} × {i.get('qty',1)} — {fmt(i.get('price',0)*i.get('qty',1))} so'm\n" for i in items[:10])
    disc = o.get("discount",0)
    total = o.get("total",0)
    txt = f"{em} <b>Buyurtma #{o['id']}</b> — <b>{lb}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
    if admin: txt += f"👤 ID: <code>{o.get('tg_user_id','-')}</code>\n"
    txt += f"🙋 <b>{o.get('full_name','-')}</b>\n📞 <code>{o.get('phone','-')}</code>\n"
    if o.get("size"):  txt += f"📏 O'lcham: {o['size']}\n"
    if o.get("color"): txt += f"🎨 Rang: {o['color']}\n"
    if o.get("promo_code"): txt += f"🏷️ Promo: {o['promo_code']} (-{disc}%)\n"
    if o.get("note"): txt += f"💬 {o['note']}\n"
    txt += f"\n🛍 Mahsulotlar:\n{lines}\n💰 <b>Jami: {fmt(total)} so'm</b>\n🕐 {o.get('created_at','')}"
    return txt

async def is_sub(uid):
    try:
        m = await bot.get_chat_member(CHANNEL, uid)
        return m.status not in ("left","kicked","banned")
    except: return True

# ── /START ────────────────────────────────────────────────────────────────────
@dp.message(CommandStart())
async def start(msg: Message, state: FSMContext):
    await state.clear()
    uid  = msg.from_user.id
    name = f"{msg.from_user.first_name or ''} {msg.from_user.last_name or ''}".strip() or "Foydalanuvchi"
    uname = msg.from_user.username or ""
    args  = msg.text.split()
    ref   = args[1] if len(args) > 1 else ""
    reg_user(uid, name, uname, ref)

    # ADMIN
    if uid == ADMIN_ID:
        conn = db()
        prods   = conn.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0]
        orders  = conn.execute("SELECT COUNT(*) FROM orders WHERE status='new'").fetchone()[0]
        users_c = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        rev     = conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status='delivered'").fetchone()[0]
        conn.close()
        await msg.answer(
            f"👑 <b>ADMIN PANEL — {SHOP_NAME}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"📦 Mahsulotlar: <b>{prods} ta</b>\n"
            f"🆕 Yangi buyurtmalar: <b>{orders} ta</b>\n"
            f"👥 Foydalanuvchilar: <b>{users_c} ta</b>\n"
            f"💰 Jami daromad: <b>{fmt(rev)} so'm</b>\n\n"
            "👇 Quyidagi tugmalardan foydalaning:",
            reply_markup=admin_kb()
        )
        return

    # OBUNA TEKSHIRISH
    if not await is_sub(uid):
        await msg.answer(
            f"👋 Salom, <b>{name}</b>!\n\n"
            f"🔒 <b>{SHOP_NAME}</b> ga kirish uchun\n"
            "avval kanalimizga obuna bo'ling!\n\n"
            "📢 Kanalda: chegirmalar, yangiliklar, sovg'alar!",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text=f"📢 Kanalga obuna bo'lish", url=f"https://t.me/{CHANNEL.lstrip('@')}")],
                [InlineKeyboardButton(text="✅ Obuna bo'ldim, kirish", callback_data="check_sub")],
            ])
        )
        return

    u = get_user(uid)
    pts = u["points"] if u else 0
    vip = "👑 VIP" if (u and u["vip"]) else ""
    await msg.answer(
        f"👋 Salom, <b>{name}</b>! {vip}\n\n"
        f"🛍 <b>{SHOP_NAME}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"⭐ Ballaringiz: <b>{fmt(pts)}</b>\n"
        "🔥 Eng yaxshi narxlar!\n"
        "🆓 Yangi obunachilarga promo kod: <code>UZUM10</code> (-10%)\n\n"
        "👇 Do'konni oching:",
        reply_markup=main_kb()
    )

@dp.callback_query(F.data == "check_sub")
async def check_sub(call: CallbackQuery, state: FSMContext):
    if not await is_sub(call.from_user.id):
        await call.answer("❌ Hali obuna bo'lmagansiz!", show_alert=True); return
    await call.message.delete()
    uid   = call.from_user.id
    name  = f"{call.from_user.first_name or ''} {call.from_user.last_name or ''}".strip()
    uname = call.from_user.username or ""
    reg_user(uid, name, uname)
    await call.message.answer(
        f"✅ Rahmat! Xush kelibsiz, <b>{name}</b>!\n\n"
        "🎁 Birinchi xaridingizga promo kod: <code>UZUM10</code> (-10%)\n\n"
        "👇 Do'konni oching:",
        reply_markup=main_kb()
    )

# ── FOYDALANUVCHI TUGMALARI ───────────────────────────────────────────────────
@dp.message(F.text == "🛒 Buyurtmalarim")
async def my_orders(msg: Message):
    conn = db()
    rows = conn.execute("SELECT * FROM orders WHERE tg_user_id=? ORDER BY id DESC LIMIT 5",
                        (str(msg.from_user.id),)).fetchall()
    conn.close()
    if not rows:
        await msg.answer("📭 Hali buyurtma bermadingiz!\n\n🛍 Do'konni oching va xarid qiling!", reply_markup=main_kb())
        return
    await msg.answer("📦 <b>Oxirgi 5 ta buyurtmangiz:</b>")
    for r in rows:
        o = dict(r)
        em, lb = STATUS.get(o["status"], ("❓","?"))
        await msg.answer(f"{em} <b>#{o['id']}</b> — {lb}\n💰 {fmt(o['total'])} so'm\n🕐 {o['created_at']}")

@dp.message(F.text == "🏆 Ballarim")
async def my_points(msg: Message):
    u = get_user(msg.from_user.id)
    if not u:
        await msg.answer("❌ Ma'lumot topilmadi"); return
    vip = "👑 VIP mijoz" if u["vip"] else "⬆️ VIP ga: 500 000 so'm xarid kerak"
    await msg.answer(
        f"🏆 <b>Sizning profilingiz</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"👤 {u['full_name']}\n"
        f"⭐ Ballar: <b>{fmt(u['points'])}</b>\n"
        f"📦 Buyurtmalar: <b>{u['orders_count']}</b>\n"
        f"💰 Jami xarid: <b>{fmt(u['total_spent'])} so'm</b>\n"
        f"🎖 Status: <b>{vip}</b>\n\n"
        f"📌 Ball olish usullari:\n"
        f"  • Har 1 000 so'm xarid = 1 ball\n"
        f"  • Do'st taklif = 200 ball\n"
        f"  🎁 500 ball = 5 000 so'm chegirma",
        reply_markup=main_kb()
    )

@dp.message(F.text == "👥 Do'stni taklif qil")
async def referral(msg: Message):
    u = get_user(msg.from_user.id)
    if not u:
        await msg.answer("❌ Avval /start bosing"); return
    rc = u["referral_code"]
    me = await bot.get_me()
    link = f"https://t.me/{me.username}?start={rc}"
    conn = db()
    inv = conn.execute("SELECT COUNT(*) FROM users WHERE referred_by=?", (rc,)).fetchone()[0]
    conn.close()
    await msg.answer(
        f"👥 <b>Referal tizimi</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"Do'stingizni taklif qiling → <b>200 ball</b> oling!\n\n"
        f"🔗 Sizning havolangiz:\n<code>{link}</code>\n\n"
        f"👥 Taklif qilganlar: <b>{inv} ta</b>\n"
        f"⭐ Ballaringiz: <b>{fmt(u['points'])}</b>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📤 Do'stlarga ulashish",
             url=f"https://t.me/share/url?url={link}&text=🛍 {SHOP_NAME} da ajoyib narxlar! Obuna bo'ling!")],
        ])
    )

@dp.message(F.text == "📞 Yordam")
async def support(msg: Message):
    await msg.answer(
        f"📞 <b>Yordam markazi</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"Admin bilan bog'laning: {SUPPORT}\n\n"
        f"🕐 Ish vaqti: 09:00 — 22:00",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="💬 Adminga yozish", url=f"https://t.me/{SUPPORT.lstrip('@')}")],
        ])
    )

# ── ADMIN: MAHSULOT QO'SHISH ──────────────────────────────────────────────────
@dp.message(F.text == "➕ Mahsulot qo'shish")
async def add_product_start(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    await state.clear()
    await state.update_data(photos=[])
    await msg.answer(
        "📸 <b>Mahsulot qo'shish</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        "1️⃣ <b>Mahsulot rasmini yuboring</b>\n"
        "• 10 tagacha rasm yuborishingiz mumkin\n"
        "• Birinchi rasm — asosiy rasm bo'ladi\n\n"
        "Rasmlar yuborib bo'lgach, <b>Nomini yozish</b> tugmasini bosing:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✏️ Nomini yozishga o'tish →", callback_data="to_name")]
        ])
    )
    await state.set_state(AddProd.photo)

@dp.message(AddProd.photo, F.photo)
async def got_photos(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    data   = await state.get_data()
    photos = data.get("photos", [])
    fid    = msg.photo[-1].file_id
    f      = await bot.get_file(fid)
    url    = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{f.file_path}"
    photos.append(url)
    await state.update_data(photos=photos)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"✅ {len(photos)} ta rasm | Nomini yozish →", callback_data="to_name")]
    ])
    await msg.answer(f"📸 {len(photos)}-rasm qabul qilindi! {'(max 10)' if len(photos)<10 else '✅ Maksimal'}\nYana rasm yuboring yoki nomini yozishga o'ting:", reply_markup=kb)
    if len(photos) >= 10:
        await state.set_state(AddProd.name)
        await msg.answer("✏️ Mahsulot <b>nomini</b> yozing:", reply_markup=ReplyKeyboardRemove())

@dp.callback_query(F.data == "to_name")
async def to_name(call: CallbackQuery, state: FSMContext):
    if call.from_user.id != ADMIN_ID: return
    data = await state.get_data()
    if not data.get("photos"):
        await call.answer("❌ Kamida 1 ta rasm yuboring!", show_alert=True); return
    await call.message.answer("✏️ Mahsulot <b>nomini</b> yozing:\nMasalan: Oversize Futbolka", reply_markup=ReplyKeyboardRemove())
    await state.set_state(AddProd.name)

@dp.message(AddProd.name)
async def got_name(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    await state.update_data(name=msg.text.strip())
    await msg.answer("💰 <b>Narxini</b> yozing (faqat raqam, so'mda):\nMasalan: 150000")
    await state.set_state(AddProd.price)

@dp.message(AddProd.price)
async def got_price(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    try:
        p = int(msg.text.strip().replace(" ","").replace(",",""))
        await state.update_data(price=p)
        await msg.answer("💸 <b>Eski narxini</b> yozing (chegirma ko'rsatish uchun):\nMasalan: 200000\n\n<i>Chegirma bo'lmasa 0 yozing</i>")
        await state.set_state(AddProd.old_price)
    except:
        await msg.answer("❌ Faqat raqam! Masalan: 150000")

@dp.message(AddProd.old_price)
async def got_old(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    try:
        o = int(msg.text.strip().replace(" ","").replace(",",""))
        await state.update_data(old_price=o)
        await msg.answer("📝 <b>Tavsifini</b> yozing:\nMasalan: 100% paxta, S-XXL o'lcham\n\n<i>Tavsif bo'lmasa 0 yozing</i>")
        await state.set_state(AddProd.desc)
    except:
        await msg.answer("❌ Faqat raqam!")

@dp.message(AddProd.desc)
async def got_desc(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    desc = "" if msg.text.strip() == "0" else msg.text.strip()
    await state.update_data(description=desc)
    await msg.answer("🏷️ <b>Badge tanlang:</b>", reply_markup=badge_kb())
    await state.set_state(AddProd.badge)

@dp.callback_query(F.data.startswith("b_"), AddProd.badge)
async def got_badge(call: CallbackQuery, state: FSMContext):
    if call.from_user.id != ADMIN_ID: return
    badge = call.data[2:]
    await state.update_data(badge=badge)
    await call.message.answer("📂 <b>Kategoriya tanlang:</b>", reply_markup=cat_kb())
    await state.set_state(AddProd.category)

@dp.callback_query(F.data.startswith("cat_"), AddProd.category)
async def got_cat(call: CallbackQuery, state: FSMContext):
    if call.from_user.id != ADMIN_ID: return
    cat_id = int(call.data[4:])
    await state.update_data(category_id=cat_id)
    await call.message.answer("📦 <b>Stok miqdori</b> yozing:\nMasalan: 50\n\n<i>Cheksiz bo'lsa 9999 yozing</i>")
    await state.set_state(AddProd.stock)

@dp.message(AddProd.stock)
async def got_stock(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    try:
        stock = int(msg.text.strip())
    except:
        await msg.answer("❌ Faqat raqam!"); return

    data   = await state.get_data()
    photos = data.get("photos", [])
    img    = photos[0] if photos else ""
    name   = data.get("name","")
    price  = data.get("price", 0)
    old    = data.get("old_price", 0)
    desc   = data.get("description","")
    badge  = data.get("badge","NEW")
    cat_id = data.get("category_id", 1)

    conn = db(); cur = conn.cursor()
    cur.execute("""INSERT INTO products(category_id,name,description,price,old_price,image,badge,stock,active,rating,sold_count,created_at)
        VALUES(?,?,?,?,?,?,?,?,1,4.5,0,?)""",
        (cat_id, name, desc, price, old, img, badge, stock, now()))
    pid = cur.lastrowid
    conn.commit(); conn.close()

    disc = round((1-price/old)*100) if old > price > 0 else 0
    caption = (
        f"✅ <b>Mahsulot qo'shildi! #{pid}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"📦 <b>{name}</b>\n"
        f"💰 {fmt(price)} so'm" +
        (f" | 💸 {fmt(old)} so'm (-{disc}%)" if disc else "") +
        (f"\n📝 {desc}" if desc else "") +
        f"\n🏷️ {badge} | 📦 {stock} ta | 🖼 {len(photos)} rasm"
    )
    try:
        await msg.answer_photo(img, caption=caption)
    except:
        await msg.answer(caption)

    await msg.answer(
        "🎉 Do'konga qo'shildi!",
        reply_markup=ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="➕ Yana mahsulot qo'shish")],
            [KeyboardButton(text="📦 Buyurtmalar"), KeyboardButton(text="📊 Statistika")],
            [KeyboardButton(text="🛍 Do'konni ochish", web_app=WebAppInfo(url=WEB_URL))],
            [KeyboardButton(text="🔙 Admin panelga qaytish")],
        ], resize_keyboard=True)
    )
    await state.clear()

@dp.message(F.text == "➕ Yana mahsulot qo'shish")
async def add_again(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    await add_product_start(msg, state)

@dp.message(F.text == "🔙 Admin panelga qaytish")
async def back_admin(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    await state.clear()
    await start(msg, state)

# ── ADMIN: BUYURTMALAR ────────────────────────────────────────────────────────
@dp.message(F.text == "📦 Buyurtmalar")
async def admin_orders(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    conn = db()
    rows = conn.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 10").fetchall()
    conn.close()
    if not rows:
        await msg.answer("📭 Buyurtma yo'q hali"); return
    await msg.answer(f"📦 <b>Oxirgi 10 ta buyurtma:</b>")
    for r in rows:
        o = dict(r)
        await msg.answer(order_text(o, admin=True), reply_markup=order_kb(o["id"], o["status"]))

@dp.callback_query(F.data.startswith("o_"))
async def order_action(call: CallbackQuery, state: FSMContext):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌", show_alert=True); return
    parts  = call.data.split("_")
    action = parts[1]
    oid    = int(parts[2])
    conn   = db()

    if action == "reply":
        await state.update_data(reply_order_id=oid)
        order = dict(conn.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone())
        conn.close()
        await call.message.answer(
            f"💬 <b>#{oid} buyurtma egasiga xabar yozing:</b>\n"
            f"👤 {order.get('full_name','-')}\n📞 {order.get('phone','-')}",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="❌ Bekor", callback_data="cancel_reply")]
            ])
        )
        await state.set_state(OrderReply.msg)
        return

    status_map = {"confirm":"confirmed","cancel":"cancelled","deliver":"delivering","done":"delivered"}
    ns = status_map.get(action)
    if not ns: conn.close(); return
    conn.execute("UPDATE orders SET status=? WHERE id=?", (ns, oid))
    conn.commit()
    order = dict(conn.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone())
    conn.close()

    em, lb = STATUS.get(ns, ("❓",""))
    await call.answer(f"{em} {lb}!", show_alert=True)
    await call.message.edit_reply_markup(reply_markup=order_kb(oid, ns))

    tg_uid = order.get("tg_user_id")
    if tg_uid:
        msgs = {
            "confirmed":  f"✅ <b>Buyurtma #{oid} tasdiqlandi!</b>\n\n📞 Admin tez orada bog'lanadi.",
            "delivering": f"🚚 <b>Buyurtma #{oid} yo'lda!</b>\n\nYaqinda yetib keladi.",
            "delivered":  f"🎉 <b>Buyurtma #{oid} yetkazildi!</b>\n\nRahmat! Yana keling! 🛍",
            "cancelled":  f"❌ <b>Buyurtma #{oid} bekor qilindi.</b>\n\nSavollar: {SUPPORT}",
        }
        if ns in msgs:
            try:
                await bot.send_message(int(tg_uid), msgs[ns], reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="🛍 Do'konni ochish", web_app=WebAppInfo(url=WEB_URL))]
                ]))
            except: pass

@dp.callback_query(F.data == "cancel_reply")
async def cancel_reply(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.delete()
    await call.answer("Bekor qilindi")

@dp.message(OrderReply.msg)
async def send_order_reply(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    data = await state.get_data()
    oid  = data.get("reply_order_id")
    conn = db()
    order = conn.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()
    conn.close()
    if not order:
        await msg.answer("❌ Buyurtma topilmadi"); await state.clear(); return
    tg_uid = order["tg_user_id"]
    try:
        await bot.send_message(int(tg_uid),
            f"💬 <b>{SHOP_NAME} admini:</b>\n\n{msg.text}\n\n<i>Buyurtma #{oid}</i>")
        await msg.answer(f"✅ Xabar yuborildi → #{oid}", reply_markup=admin_kb())
    except:
        await msg.answer("❌ Foydalanuvchiga xabar yetmadi", reply_markup=admin_kb())
    await state.clear()

# ── ADMIN: STATISTIKA ─────────────────────────────────────────────────────────
@dp.message(F.text == "📊 Statistika")
async def stats(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    conn  = db()
    today = datetime.now().strftime("%Y-%m-%d")
    prods  = conn.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0]
    users  = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    orders = conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    new_o  = conn.execute("SELECT COUNT(*) FROM orders WHERE status='new'").fetchone()[0]
    today_o= conn.execute("SELECT COUNT(*) FROM orders WHERE created_at LIKE ?", (today+"%",)).fetchone()[0]
    today_r= conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE created_at LIKE ? AND status!='cancelled'", (today+"%",)).fetchone()[0]
    total_r= conn.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status='delivered'").fetchone()[0]
    vip_c  = conn.execute("SELECT COUNT(*) FROM users WHERE vip=1").fetchone()[0]
    conn.close()
    await msg.answer(
        f"📊 <b>Statistika — {SHOP_NAME}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"📦 Mahsulotlar: <b>{prods} ta</b>\n"
        f"👥 Foydalanuvchilar: <b>{users} ta</b>\n"
        f"👑 VIP mijozlar: <b>{vip_c} ta</b>\n\n"
        f"📋 Jami buyurtmalar: <b>{orders} ta</b>\n"
        f"🆕 Yangi: <b>{new_o} ta</b>\n"
        f"📅 Bugun: <b>{today_o} ta</b>\n\n"
        f"💰 Bugungi daromad: <b>{fmt(today_r)} so'm</b>\n"
        f"💎 Jami daromad: <b>{fmt(total_r)} so'm</b>",
        reply_markup=admin_kb()
    )

# ── ADMIN: BROADCAST ──────────────────────────────────────────────────────────
@dp.message(F.text == "📢 Broadcast")
async def broadcast_start(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    conn  = db()
    count = conn.execute("SELECT COUNT(*) FROM users WHERE blocked=0").fetchone()[0]
    conn.close()
    await msg.answer(
        f"📢 <b>Broadcast</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"👥 Yuboriladi: <b>{count} ta</b> foydalanuvchiga\n\n"
        "📝 Matn yozing yoki 📸 Rasm bilan caption yozing:\n\n"
        "<i>Bekor qilish uchun /cancel</i>",
        reply_markup=ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="❌ Bekor")]], resize_keyboard=True)
    )
    await state.set_state(Broadcast.msg)

@dp.message(F.text == "❌ Bekor")
async def cancel_any(msg: Message, state: FSMContext):
    await state.clear()
    if msg.from_user.id == ADMIN_ID:
        await msg.answer("❌ Bekor qilindi", reply_markup=admin_kb())
    else:
        await msg.answer("❌ Bekor qilindi", reply_markup=main_kb())

@dp.message(Broadcast.msg)
async def do_broadcast(msg: Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    text     = msg.text or msg.caption or ""
    photo_id = msg.photo[-1].file_id if msg.photo else None
    conn     = db()
    users    = conn.execute("SELECT tg_user_id FROM users WHERE blocked=0").fetchall()
    conn.close()
    sent = 0; failed = 0
    prog = await msg.answer(f"📤 Yuborilmoqda... 0/{len(users)}")
    for i, u in enumerate(users):
        try:
            uid = int(u["tg_user_id"])
            shop_kb = InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="🛍 Do'konni ochish", web_app=WebAppInfo(url=WEB_URL))
            ]])
            if photo_id:
                await bot.send_photo(uid, photo_id, caption=text, reply_markup=shop_kb)
            else:
                await bot.send_message(uid, text, reply_markup=shop_kb)
            sent += 1
        except: failed += 1
        if (i+1) % 20 == 0:
            try: await prog.edit_text(f"📤 Yuborilmoqda... {i+1}/{len(users)}")
            except: pass
        await asyncio.sleep(0.05)
    await prog.edit_text(f"✅ Broadcast tugadi!\n✅ Yuborildi: {sent}\n❌ Xato: {failed}")
    await msg.answer("Tugadi!", reply_markup=admin_kb())
    await state.clear()

# ── ADMIN: PROMO KOD ──────────────────────────────────────────────────────────
@dp.message(F.text == "🏷️ Promo kod")
async def promo_menu(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    conn  = db()
    promos = conn.execute("SELECT * FROM promo_codes ORDER BY id DESC LIMIT 10").fetchall()
    conn.close()
    text = "🏷️ <b>Promo kodlar</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
    for p in promos:
        status = "✅" if p["active"] else "❌"
        text += f"{status} <code>{p['code']}</code> — {p['discount_percent']}% | {p['used_count']}/{p['max_uses']}\n"
    text += "\n<b>Yangi kod yaratish uchun yozing:</b>\n<code>/promo KOD FOIZ MAKS</code>\nMasalan: <code>/promo YANGI20 20 100</code>"
    await msg.answer(text, reply_markup=admin_kb())

@dp.message(Command("promo"))
async def make_promo(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    parts = msg.text.split()
    if len(parts) < 3:
        await msg.answer("❌ Format: /promo KOD FOIZ MAKS\nMasalan: /promo YANGI20 20 100"); return
    code = parts[1].upper()
    try:
        disc = int(parts[2])
        maks = int(parts[3]) if len(parts) > 3 else 100
    except:
        await msg.answer("❌ Foiz va maks raqam bo'lishi kerak"); return
    conn = db(); cur = conn.cursor()
    try:
        cur.execute("INSERT INTO promo_codes(code,discount_percent,max_uses,active,created_at) VALUES(?,?,?,1,?)",
                    (code, disc, maks, now()))
        conn.commit()
        await msg.answer(f"✅ Promo kod yaratildi!\n\n🏷️ Kod: <code>{code}</code>\n💸 Chegirma: {disc}%\n👥 Max: {maks} ta")
    except:
        await msg.answer("❌ Bu kod allaqachon mavjud!")
    conn.close()

# ── ADMIN: MAHSULOT O'CHIRISH ─────────────────────────────────────────────────
@dp.message(F.text == "❌ Mahsulot o'chirish")
async def delete_product_menu(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    conn  = db()
    prods = conn.execute("SELECT id, name, price FROM products WHERE active=1 ORDER BY id DESC LIMIT 20").fetchall()
    conn.close()
    if not prods:
        await msg.answer("📭 Mahsulot yo'q"); return
    kb = InlineKeyboardBuilder()
    for p in prods:
        kb.button(text=f"❌ #{p['id']} {p['name'][:25]}", callback_data=f"del_{p['id']}")
    kb.adjust(1)
    await msg.answer("🗑 <b>O'chirish uchun tanlang:</b>", reply_markup=kb.as_markup())

@dp.callback_query(F.data.startswith("del_"))
async def delete_product(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("❌", show_alert=True); return
    pid = int(call.data[4:])
    conn = db()
    prod = conn.execute("SELECT name FROM products WHERE id=?", (pid,)).fetchone()
    conn.execute("UPDATE products SET active=0 WHERE id=?", (pid,))
    conn.commit(); conn.close()
    await call.answer(f"✅ O'chirildi: {prod['name'] if prod else ''}", show_alert=True)
    await call.message.edit_reply_markup(reply_markup=None)

# ── ADMIN: FOYDALANUVCHILAR ───────────────────────────────────────────────────
@dp.message(F.text == "👥 Foydalanuvchilar")
async def admin_users(msg: Message):
    if msg.from_user.id != ADMIN_ID: return
    conn  = db()
    total = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    vip   = conn.execute("SELECT COUNT(*) FROM users WHERE vip=1").fetchone()[0]
    users = conn.execute("SELECT * FROM users ORDER BY id DESC LIMIT 10").fetchall()
    conn.close()
    text = f"👥 <b>Foydalanuvchilar ({total} ta, {vip} VIP)</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
    for u in users:
        vip_ico = "👑" if u["vip"] else "👤"
        text += f"{vip_ico} <b>{u['full_name'] or 'Noma\\'lum'}</b>"
        if u["username"]: text += f" @{u['username']}"
        text += f" | ⭐{fmt(u['points'])} | 📦{u['orders_count']}\n"
    await msg.answer(text, reply_markup=admin_kb())

# ── WEB APP DATA ──────────────────────────────────────────────────────────────
@dp.message(F.web_app_data)
async def webapp_data(msg: Message):
    try: data = json.loads(msg.web_app_data.data)
    except: return
    oid   = data.get("order_id","?")
    total = data.get("total", 0)
    phone = data.get("phone","")
    fname = data.get("full_name","")
    await msg.answer(
        f"✅ <b>Buyurtma #{oid} qabul qilindi!</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
        f"💰 Jami: <b>{fmt(total)} so'm</b>\n📞 {phone}\n\n"
        f"⏳ Admin tez orada bog'lanadi!\n💬 Savol: {SUPPORT}",
        reply_markup=main_kb()
    )
    if oid != "?":
        conn = db()
        order = conn.execute("SELECT * FROM orders WHERE id=?", (int(oid),)).fetchone()
        conn.close()
        if order:
            o = dict(order)
            try:
                await bot.send_message(ADMIN_ID, "🆕 <b>YANGI BUYURTMA!</b>\n"+order_text(o, True),
                                        reply_markup=order_kb(int(oid), "new"))
            except: pass
            try:
                await bot.send_message(CHANNEL,
                    f"🛒 <b>YANGI BUYURTMA #{oid}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"🙋 {o.get('full_name','-')}\n📞 <code>{o.get('phone','-')}</code>\n"
                    f"💰 <b>{fmt(o.get('total',0))} so'm</b>\n<i>{SHOP_NAME}</i>")
            except: pass
            # Update user stats
            tg_uid = o.get("tg_user_id","")
            if tg_uid:
                pts = max(1, total // 1000)
                conn2 = db()
                conn2.execute("UPDATE users SET total_spent=total_spent+?,orders_count=orders_count+1,points=points+?,vip=CASE WHEN total_spent+?>500000 THEN 1 ELSE vip END WHERE tg_user_id=?",
                              (total, pts, total, tg_uid))
                conn2.commit(); conn2.close()

# ── MAIN ──────────────────────────────────────────────────────────────────────
async def main():
    init_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
